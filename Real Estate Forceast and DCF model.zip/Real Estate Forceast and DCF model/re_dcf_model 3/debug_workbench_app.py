"""
RE DCF Workbench v2

Purpose:
- Diagnostic underwriting interface, not client-facing UX.
- Exposes assumptions, formulas, source tags, dependency logic, cash-flow streams,
  scenario recipes, and KPI bridges.

Run:
    python3 -m pip install -r requirements_debug.txt
    python3 -m streamlit run debug_workbench_app.py
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, is_dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

import pandas as pd
import streamlit as st

from tests.fixtures import make_test_deal
from engine.assumptions import AbsorptionCurve
from engine.revenue import compute_revenue, get_stabilization_month
from engine.opex import compute_opex
from engine.capex import compute_capex
from engine.debt import compute_debt
from engine.dcf import build_cash_flows, compute_irr, compute_npv
from engine.waterfall import allocate_waterfall
from engine.kpis import compute_kpis


# =============================================================================
# Formatting helpers
# =============================================================================

def money(x: Any) -> str:
    if x is None:
        return "—"
    try:
        x = float(x)
    except Exception:
        return str(x)
    sign = "-" if x < 0 else ""
    x = abs(x)
    if x >= 1_000_000:
        return f"{sign}${x/1_000_000:,.2f}M"
    if x >= 1_000:
        return f"{sign}${x/1_000:,.0f}K"
    return f"{sign}${x:,.0f}"


def pct(x: Any) -> str:
    if x is None:
        return "—"
    try:
        return f"{float(x) * 100:,.2f}%"
    except Exception:
        return str(x)


def xmult(x: Any) -> str:
    if x is None:
        return "—"
    try:
        return f"{float(x):,.2f}x"
    except Exception:
        return str(x)


def safe_float(x: Any) -> Optional[float]:
    try:
        return float(x)
    except Exception:
        return None


def dataclass_rows(objs: List[Any]) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for obj in objs:
        if is_dataclass(obj):
            rows.append(asdict(obj))
        elif isinstance(obj, dict):
            rows.append(obj)
        else:
            rows.append(getattr(obj, "__dict__", {"value": obj}))
    return pd.DataFrame(rows)


def flatten_unit_detail(revenue_months, max_month: int) -> pd.DataFrame:
    rows = []
    for r in revenue_months[: max_month + 1]:
        for d in r.unit_type_detail:
            row = asdict(d)
            row["month"] = r.month
            rows.append(row)
    return pd.DataFrame(rows)


# =============================================================================
# Engine runner
# =============================================================================

def run_all_engines(a):
    rev = compute_revenue(a)
    stab_m = get_stabilization_month(rev)
    egi_series = [r.egi for r in rev]
    opex = compute_opex(a, egi_series)
    noi_series = [o.noi for o in opex]
    capex = compute_capex(a, stabilization_month=stab_m)
    const_draws = [c.const_loan_draw for c in capex]
    debt = compute_debt(a, const_draws, stab_m, noi_series)
    cfs = build_cash_flows(rev, opex, capex, debt, a, stab_m)
    wf = allocate_waterfall([cf.equity_cf for cf in cfs], a)
    kpis = compute_kpis(cfs, debt, opex, rev, a, stab_m, wf)
    return rev, stab_m, opex, capex, debt, cfs, wf, kpis


def run_kpis_only(a):
    try:
        *_, kpis = run_all_engines(a)
        return kpis
    except Exception:
        return None


# =============================================================================
# Assumption editor
# =============================================================================

def build_assumptions_from_ui():
    a = make_test_deal()

    st.sidebar.header("Deal")
    a.acquisition.purchase_price = st.sidebar.number_input(
        "Purchase price", min_value=1_000_000, max_value=500_000_000,
        value=int(a.acquisition.purchase_price), step=250_000,
    )
    a.timeline.hold_months = st.sidebar.slider("Hold months", 12, 120, a.timeline.hold_months, 6)
    a.exit.exit_month = a.timeline.hold_months
    a.discount_rate = st.sidebar.slider("Discount rate", 0.00, 0.25, a.discount_rate, 0.005)

    st.sidebar.header("Revenue / Lease-Up")
    rent_growth = st.sidebar.slider("Default rent growth", 0.00, 0.10, 0.03, 0.0025)
    stab_threshold = st.sidebar.slider(
        "Stabilization occupancy threshold", 0.70, 0.99,
        a.timeline.stabilized_occ_threshold, 0.01,
    )
    a.timeline.stabilized_occ_threshold = stab_threshold
    a.timeline.stability_confirmation_months = st.sidebar.slider(
        "Stability confirmation months", 1, 6, a.timeline.stability_confirmation_months, 1,
    )

    selected_curve = st.sidebar.selectbox(
        "Default absorption curve", [c.value for c in AbsorptionCurve], index=0,
    )
    for ut in a.property.unit_types:
        ut.default_rent_growth = rent_growth
        ut.absorption_curve = AbsorptionCurve(selected_curve)

    with st.sidebar.expander("1BR quick edit", expanded=False):
        one_br = next((u for u in a.property.unit_types if u.label == "1BR"), a.property.unit_types[0])
        one_br.in_place_rent = st.number_input("1BR in-place rent", 500, 5000, int(one_br.in_place_rent), 25)
        one_br.market_rent = st.number_input("1BR market rent", 500, 6000, int(one_br.market_rent), 25)
        one_br.in_place_occupancy = st.slider("1BR in-place occupancy", 0.50, 1.00, float(one_br.in_place_occupancy), 0.01)
        one_br.stabilized_occupancy = st.slider("1BR stabilized occupancy", 0.50, 1.00, float(one_br.stabilized_occupancy), 0.01)
        one_br.absorption_period_months = st.slider("1BR absorption months", 1, 48, int(one_br.absorption_period_months), 1)
        one_br.concession_weeks = st.slider("1BR concession weeks", 0.0, 12.0, float(one_br.concession_weeks), 0.5)

    st.sidebar.header("Renovation / CapEx")
    a.renovation.include_renovation = st.sidebar.checkbox("Include renovation", a.renovation.include_renovation)
    a.renovation.hard_cost_per_unit = st.sidebar.number_input("Hard cost / unit", 0, 100_000, int(a.renovation.hard_cost_per_unit), 500)
    a.renovation.contingency_pct = st.sidebar.slider("Contingency", 0.00, 0.40, a.renovation.contingency_pct, 0.01)
    a.renovation.reno_period_months = st.sidebar.slider("Reno period months", 1, 60, a.renovation.reno_period_months, 1)
    a.renovation.common_area_cost = st.sidebar.number_input("Common area cost", 0, 10_000_000, int(a.renovation.common_area_cost), 50_000)
    a.renovation.exterior_cost = st.sidebar.number_input("Exterior cost", 0, 10_000_000, int(a.renovation.exterior_cost), 50_000)

    st.sidebar.header("Debt")
    a.acq_loan.include = st.sidebar.checkbox("Include acquisition loan", a.acq_loan.include)
    a.acq_loan.ltv_or_ltc = st.sidebar.slider("Acq loan LTV", 0.00, 0.90, a.acq_loan.ltv_or_ltc, 0.01)
    a.acq_loan.interest_rate = st.sidebar.slider("Acq loan rate", 0.00, 0.15, a.acq_loan.interest_rate, 0.0025)
    a.acq_loan.io_period_months = st.sidebar.slider("Acq IO months", 0, 60, a.acq_loan.io_period_months, 6)

    a.const_loan.include = st.sidebar.checkbox("Include construction loan", a.const_loan.include)
    a.const_loan.max_commitment_pct_of_cost = st.sidebar.slider("Construction LTC on reno cost", 0.00, 1.00, a.const_loan.max_commitment_pct_of_cost, 0.01)
    a.const_loan.interest_rate = st.sidebar.slider("Construction loan rate", 0.00, 0.18, a.const_loan.interest_rate, 0.0025)

    a.refi.include = st.sidebar.checkbox("Include refi", a.refi.include)
    refi_trigger = st.sidebar.slider("Refi trigger month", 1, max(1, a.timeline.hold_months - 1), a.refi.trigger_month or 24, 1)
    a.refi.trigger_month = refi_trigger
    a.refi.ltv = st.sidebar.slider("Refi LTV", 0.00, 0.85, a.refi.ltv, 0.01)
    a.refi.interest_rate = st.sidebar.slider("Refi rate", 0.00, 0.15, a.refi.interest_rate, 0.0025)

    st.sidebar.header("Exit")
    a.exit.exit_cap_rate = st.sidebar.slider("Exit cap rate", 0.02, 0.12, a.exit.exit_cap_rate, 0.00125)
    a.exit.selling_cost_pct = st.sidebar.slider("Selling cost", 0.00, 0.08, a.exit.selling_cost_pct, 0.0025)
    a.market.market_cap_rate_going_in = st.sidebar.slider("Market cap for refi sizing", 0.02, 0.12, a.market.market_cap_rate_going_in, 0.00125)

    st.sidebar.header("OpEx")
    a.opex.repairs_maintenance.cost_per_unit_per_year = st.sidebar.number_input("R&M / unit / year", 0, 5000, int(a.opex.repairs_maintenance.cost_per_unit_per_year), 25)
    a.opex.payroll.cost_per_unit_per_year = st.sidebar.number_input("Payroll / unit / year", 0, 8000, int(a.opex.payroll.cost_per_unit_per_year), 25)
    a.opex.property_tax.cost_per_unit_per_year = st.sidebar.number_input("Tax / unit / year", 0, 10000, int(a.opex.property_tax.cost_per_unit_per_year), 25)
    a.opex.management_fee.pct_of_egi = st.sidebar.slider("Management fee % EGI", 0.00, 0.10, a.opex.management_fee.pct_of_egi, 0.0025)
    a.opex.reserves.cost_per_unit_per_year = st.sidebar.number_input("Reserves / unit / year", 0, 2000, int(a.opex.reserves.cost_per_unit_per_year), 25)

    return a


# =============================================================================
# Formula / source intelligence
# =============================================================================

def kpi_values(kpis) -> Dict[str, Any]:
    return {
        "Levered IRR": kpis.levered_irr,
        "Unlevered IRR": kpis.unlevered_irr,
        "Equity Multiple": kpis.equity_multiple,
        "NPV": kpis.npv,
        "Yield on Cost": kpis.yield_on_cost,
        "Development Spread": kpis.development_spread_bps,
        "DSCR Stabilized": kpis.dscr_stabilized,
        "Stabilization Month": kpis.stabilization_month,
    }


def formula_dictionary(a, cashflows, debt, opex, kpis) -> Dict[str, Dict[str, Any]]:
    exit_m = a.exit.exit_month
    exit_cf = cashflows[exit_m]
    exit_noi = exit_cf.noi * 12
    gross_exit_value = exit_noi / a.exit.exit_cap_rate if a.exit.exit_cap_rate > 0 else 0.0
    levered_cfs = [cf.equity_cf for cf in cashflows]
    unlevered_cfs = [cf.unlevered_cf for cf in cashflows]

    total_in = sum(-c for c in levered_cfs if c < 0)
    total_out = sum(c for c in levered_cfs if c > 0)

    return {
        "Levered IRR": {
            "definition": "Annualized internal rate of return on the equity cash-flow stream.",
            "formula": "IRR([equity_cf_month_0 ... equity_cf_exit]) annualized as (1 + monthly_irr)^12 - 1",
            "source": "engine.kpis.compute_kpis → engine.dcf.compute_irr(equity_cfs)",
            "inputs": ["equity_cf", "NOI", "debt_service", "refi_proceeds", "sale_proceeds", "equity-funded capex", "initial equity"],
            "current": pct(kpis.levered_irr),
            "bridge": [
                {"Component": "Initial equity outflow", "Value": money(cashflows[0].equity_cf)},
                {"Component": "Total positive equity CF", "Value": money(total_out)},
                {"Component": "Total negative equity CF", "Value": money(-total_in)},
                {"Component": "Exit month equity CF", "Value": money(exit_cf.equity_cf)},
            ],
            "cashflows": levered_cfs,
        },
        "Unlevered IRR": {
            "definition": "Property-level IRR before debt. Includes acquisition, property NOI, total renovation draws, ongoing reserves, and unlevered terminal sale proceeds.",
            "formula": "IRR(NOI - total_reno_draw - ongoing_capex + unlevered_sale_proceeds - acquisition_outflow at month 0)",
            "source": "engine.dcf.build_cash_flows → CashFlowMonth.unlevered_cf → compute_irr",
            "inputs": ["purchase price", "closing costs", "NOI", "total renovation draw", "ongoing capex", "gross exit value", "selling cost", "disposition fee"],
            "current": pct(kpis.unlevered_irr),
            "bridge": [
                {"Component": "Month 0 unlevered CF", "Value": money(cashflows[0].unlevered_cf)},
                {"Component": "Exit month unlevered CF", "Value": money(exit_cf.unlevered_cf)},
                {"Component": "Total positive unlevered CF", "Value": money(sum(x for x in unlevered_cfs if x > 0))},
                {"Component": "Total negative unlevered CF", "Value": money(sum(x for x in unlevered_cfs if x < 0))},
            ],
            "cashflows": unlevered_cfs,
        },
        "Exit Value": {
            "definition": "Terminal property value before debt payoff, based on exit NOI and exit cap rate.",
            "formula": "Exit Value = Exit Month NOI × 12 / Exit Cap Rate",
            "source": "engine.dcf.build_cash_flows and engine.kpis.compute_kpis",
            "inputs": ["exit month NOI", "exit cap rate"],
            "current": money(gross_exit_value),
            "bridge": [
                {"Component": "Exit monthly NOI", "Value": money(exit_cf.noi)},
                {"Component": "Exit annualized NOI", "Value": money(exit_noi)},
                {"Component": "Exit cap rate", "Value": pct(a.exit.exit_cap_rate)},
                {"Component": "Gross exit value", "Value": money(gross_exit_value)},
                {"Component": "Levered net sale proceeds", "Value": money(exit_cf.sale_proceeds)},
            ],
            "cashflows": [],
        },
        "Refi Proceeds": {
            "definition": "Net cash proceeds from refinance after paying off acquisition/construction debt and refi costs.",
            "formula": "Refi Loan = Stabilized Value × Refi LTV; Net Proceeds = Refi Loan - Payoffs - Costs, floored at zero",
            "source": "engine.debt.compute_debt",
            "inputs": ["NOI at refi", "market cap rate", "refi LTV", "acquisition payoff", "construction payoff", "refi costs"],
            "current": money(sum(cf.refi_proceeds for cf in cashflows)),
            "bridge": [
                {"Component": "Total refi proceeds", "Value": money(sum(cf.refi_proceeds for cf in cashflows))},
                {"Component": "Refi LTV", "Value": pct(a.refi.ltv)},
                {"Component": "Market cap for sizing", "Value": pct(a.market.market_cap_rate_going_in)},
            ],
            "cashflows": [cf.refi_proceeds for cf in cashflows],
        },
        "DSCR Stabilized": {
            "definition": "Annualized NOI at stabilization divided by annualized debt service at stabilization.",
            "formula": "DSCR = Stabilized NOI × 12 / Stabilized Debt Service × 12",
            "source": "engine.kpis.compute_kpis",
            "inputs": ["stabilization month", "NOI", "total debt service"],
            "current": xmult(kpis.dscr_stabilized),
            "bridge": [
                {"Component": "Stabilization month", "Value": str(kpis.stabilization_month)},
                {"Component": "Monthly NOI at stabilization", "Value": money(opex[kpis.stabilization_month].noi)},
                {"Component": "Monthly debt service at stabilization", "Value": money(debt[kpis.stabilization_month].total_debt_service)},
                {"Component": "DSCR", "Value": xmult(kpis.dscr_stabilized)},
            ],
            "cashflows": [],
        },
    }


def assumption_intelligence(a, base_kpis) -> pd.DataFrame:
    base_irr = safe_float(base_kpis.levered_irr) or 0.0
    rows = []

    def test_change(label: str, source: str, confidence: str, path: str, current: str, change_text: str, changer: Callable[[Any], None]):
        b = deepcopy(a)
        changer(b)
        k = run_kpis_only(b)
        new_irr = safe_float(k.levered_irr) if k else None
        delta = None if new_irr is None else new_irr - base_irr
        impact = "Unknown"
        if delta is not None:
            ad = abs(delta)
            if ad >= 0.015:
                impact = "Very High"
            elif ad >= 0.0075:
                impact = "High"
            elif ad >= 0.0025:
                impact = "Medium"
            else:
                impact = "Low"
        rows.append({
            "Assumption": label,
            "Current": current,
            "Source": source,
            "Confidence": confidence,
            "Tested Shock": change_text,
            "Levered IRR Impact": "—" if delta is None else f"{delta*100:+.2f} pts",
            "Impact Class": impact,
            "Model Path": path,
        })

    test_change(
        "Exit Cap Rate", "Manual / Market Comp", "Medium", "a.exit.exit_cap_rate", pct(a.exit.exit_cap_rate), "+25 bps",
        lambda b: setattr(b.exit, "exit_cap_rate", b.exit.exit_cap_rate + 0.0025),
    )
    test_change(
        "Rent Growth", "Manual / Market Rent Assumption", "Medium", "unit_type.default_rent_growth", pct(a.property.unit_types[0].default_rent_growth), "+50 bps",
        lambda b: [setattr(u, "default_rent_growth", u.default_rent_growth + 0.005) for u in b.property.unit_types],
    )
    test_change(
        "Hard Cost / Unit", "Manual / Renovation Budget", "Medium", "a.renovation.hard_cost_per_unit", money(a.renovation.hard_cost_per_unit), "+10%",
        lambda b: setattr(b.renovation, "hard_cost_per_unit", b.renovation.hard_cost_per_unit * 1.10),
    )
    test_change(
        "Refi Rate", "Manual / Debt Quote", "Medium", "a.refi.interest_rate", pct(a.refi.interest_rate), "+100 bps",
        lambda b: setattr(b.refi, "interest_rate", b.refi.interest_rate + 0.01),
    )
    test_change(
        "Refi LTV", "Manual / Debt Quote", "Low-Medium", "a.refi.ltv", pct(a.refi.ltv), "-5 pts",
        lambda b: setattr(b.refi, "ltv", max(0.0, b.refi.ltv - 0.05)),
    )
    return pd.DataFrame(rows)


def apply_scenario(a, recipe: str):
    b = deepcopy(a)
    if recipe == "Base":
        return b
    if recipe == "Exit Cap Expansion":
        b.exit.exit_cap_rate += 0.005
    elif recipe == "Cost Overrun":
        b.renovation.hard_cost_per_unit *= 1.15
        b.renovation.contingency_pct += 0.05
        b.renovation.reno_period_months += 3
    elif recipe == "Lease-Up Delay":
        for u in b.property.unit_types:
            u.absorption_period_months += 6
            u.concession_weeks += 2
    elif recipe == "Refi Failure":
        b.refi.include = False
    elif recipe == "Rate Shock":
        b.acq_loan.interest_rate += 0.01
        b.const_loan.interest_rate += 0.01
        b.refi.interest_rate += 0.01
    elif recipe == "Rent Recession":
        for u in b.property.unit_types:
            u.default_rent_growth = max(0.0, u.default_rent_growth - 0.015)
            u.stabilized_occupancy = max(0.80, u.stabilized_occupancy - 0.03)
    return b


# =============================================================================
# Page
# =============================================================================

st.set_page_config(page_title="RE DCF Workbench v2", layout="wide")
st.title("RE DCF Workbench v2")
st.caption("Diagnostic underwriting interface: formulas, lineage, assumption intelligence, and scenario recipes.")

try:
    assumptions = build_assumptions_from_ui()
    revenue, stab_month, opex, capex, debt, cashflows, waterfall, kpis = run_all_engines(assumptions)
except Exception as exc:
    st.error("Engine run failed.")
    st.exception(exc)
    st.stop()

# KPI header
cols = st.columns(8)
cols[0].metric("Levered IRR", pct(kpis.levered_irr))
cols[1].metric("Unlevered IRR", pct(kpis.unlevered_irr))
cols[2].metric("Equity Multiple", xmult(kpis.equity_multiple))
cols[3].metric("NPV", money(kpis.npv))
cols[4].metric("Yield on Cost", pct(kpis.yield_on_cost))
cols[5].metric("Dev Spread", f"{kpis.development_spread_bps:,.0f} bps")
cols[6].metric("DSCR Stab", xmult(kpis.dscr_stabilized))
cols[7].metric("Stab Month", str(kpis.stabilization_month))

st.divider()

left, right = st.columns([2.2, 1.0], gap="large")

with right:
    st.subheader("Formula Drawer")
    formulas = formula_dictionary(assumptions, cashflows, debt, opex, kpis)
    selected_formula = st.selectbox("Inspect KPI / output", list(formulas.keys()))
    fd = formulas[selected_formula]
    st.markdown(f"### {selected_formula}: {fd['current']}")
    st.markdown(f"**Definition:** {fd['definition']}")
    st.markdown("**Formula:**")
    st.code(fd["formula"], language="text")
    st.markdown(f"**Source path:** `{fd['source']}`")
    st.markdown("**Inputs:** " + ", ".join(f"`{x}`" for x in fd["inputs"]))
    st.dataframe(pd.DataFrame(fd["bridge"]), hide_index=True, width="stretch")
    if fd.get("cashflows"):
        stream = fd["cashflows"]
        preview = pd.DataFrame({"month": list(range(len(stream))), "cash_flow": stream})
        st.markdown("**IRR cash-flow stream preview**")
        st.dataframe(pd.concat([preview.head(6), preview.tail(6)]), hide_index=True, width="stretch")

with left:
    main_tabs = st.tabs([
        "Command Center",
        "Formula Explorer",
        "Assumption Intelligence",
        "Scenario Recipes",
        "Engine Tables",
        "Audit Notes",
    ])

    with main_tabs[0]:
        st.subheader("Underwriting Command Center")
        exit_m = assumptions.exit.exit_month
        exit_cf = cashflows[exit_m]
        command_rows = [
            {"Bridge": "Revenue → NOI", "Formula": "EGI - OpEx", "Current Output": money(opex[min(stab_month, len(opex)-1)].noi), "Status": "Live"},
            {"Bridge": "NOI → Exit Value", "Formula": "Exit NOI × 12 / Exit Cap", "Current Output": money((exit_cf.noi * 12) / assumptions.exit.exit_cap_rate), "Status": "Live"},
            {"Bridge": "Debt → Refi", "Formula": "Refi Value × LTV - Payoffs - Costs", "Current Output": money(sum(cf.refi_proceeds for cf in cashflows)), "Status": "Live"},
            {"Bridge": "Exit → Levered IRR", "Formula": "IRR(equity cash-flow stream)", "Current Output": pct(kpis.levered_irr), "Status": "Live"},
            {"Bridge": "Property → Unlevered IRR", "Formula": "IRR(unlevered property cash-flow stream)", "Current Output": pct(kpis.unlevered_irr), "Status": "Fixed / Live"},
        ]
        st.dataframe(pd.DataFrame(command_rows), hide_index=True, width="stretch")

        st.markdown("#### KPI Bridge Snapshot")
        bridge_df = pd.DataFrame([
            {"KPI": "Levered IRR", "Value": pct(kpis.levered_irr), "Primary Drivers": "Exit value, refi proceeds, NOI, debt service", "Risk": "High sensitivity to exit cap"},
            {"KPI": "Unlevered IRR", "Value": pct(kpis.unlevered_irr), "Primary Drivers": "Purchase price, NOI, total capex, unlevered exit proceeds", "Risk": "Depends on terminal value"},
            {"KPI": "DSCR", "Value": xmult(kpis.dscr_stabilized), "Primary Drivers": "NOI and debt service at stabilization", "Risk": "Debt quote / refi sizing"},
            {"KPI": "Yield on Cost", "Value": pct(kpis.yield_on_cost), "Primary Drivers": "Stabilized NOI and total project cost", "Risk": "Reno budget and NOI quality"},
        ])
        st.dataframe(bridge_df, hide_index=True, width="stretch")

    with main_tabs[1]:
        st.subheader("Formula Explorer")
        st.markdown("""
```text
Levered IRR
│
├── Equity Cash Flow
│   ├── NOI
│   │   ├── Revenue Engine
│   │   │   ├── Unit mix
│   │   │   ├── In-place rent
│   │   │   ├── Market rent
│   │   │   ├── Absorption curve
│   │   │   └── Concessions / credit loss
│   │   └── OpEx Engine
│   │       ├── R&M
│   │       ├── Payroll
│   │       ├── Taxes
│   │       ├── Insurance
│   │       └── Management fee
│   ├── Debt Service
│   │   ├── Acquisition loan
│   │   ├── Construction loan
│   │   └── Refi loan
│   ├── Refi Proceeds
│   │   ├── NOI at refi
│   │   ├── Market cap rate
│   │   ├── Refi LTV
│   │   └── Payoffs / costs
│   └── Sale Proceeds
│       ├── Exit NOI
│       ├── Exit cap rate
│       ├── Selling cost
│       ├── Disposition fee
│       └── Loan payoff
```
""")
        st.info("This is the first version of lineage. Next build can make each node clickable and route to the exact source row.")

    with main_tabs[2]:
        st.subheader("Assumption Intelligence")
        ai_df = assumption_intelligence(assumptions, kpis)
        st.dataframe(ai_df, hide_index=True, width="stretch")
        st.caption("Impact is measured by shocking one assumption at a time and rerunning the engine against levered IRR.")

    with main_tabs[3]:
        st.subheader("Scenario Recipes")
        recipes = ["Base", "Exit Cap Expansion", "Cost Overrun", "Lease-Up Delay", "Refi Failure", "Rate Shock", "Rent Recession"]
        rows = []
        base = kpis
        for recipe in recipes:
            aa = apply_scenario(assumptions, recipe)
            kk = run_kpis_only(aa)
            if kk is None:
                rows.append({"Scenario": recipe, "Levered IRR": "Error", "Unlevered IRR": "Error", "NPV": "Error", "Equity Multiple": "Error", "IRR Delta": "Error"})
                continue
            delta = (kk.levered_irr - base.levered_irr) if kk.levered_irr is not None and base.levered_irr is not None else None
            rows.append({
                "Scenario": recipe,
                "Levered IRR": pct(kk.levered_irr),
                "Unlevered IRR": pct(kk.unlevered_irr),
                "NPV": money(kk.npv),
                "Equity Multiple": xmult(kk.equity_multiple),
                "IRR Delta": "—" if delta is None else f"{delta*100:+.2f} pts",
            })
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
        st.markdown("""
**Recipe definitions**
- **Exit Cap Expansion:** exit cap +50 bps.
- **Cost Overrun:** hard cost +15%, contingency +5 pts, renovation period +3 months.
- **Lease-Up Delay:** absorption +6 months and concessions +2 weeks.
- **Refi Failure:** refinance disabled.
- **Rate Shock:** acquisition, construction, and refi rates +100 bps.
- **Rent Recession:** rent growth -150 bps and stabilized occupancy -3 pts.
""")

    with main_tabs[4]:
        st.subheader("Engine Tables")
        max_month = st.slider("Display months", 12, assumptions.timeline.hold_months, min(36, assumptions.timeline.hold_months), 1)
        engine_tab_names = ["Revenue", "Unit Cohorts", "OpEx", "CapEx", "Debt", "DCF"]
        t_rev, t_unit, t_opex, t_capex, t_debt, t_dcf = st.tabs(engine_tab_names)
        with t_rev:
            st.code("EGI = GPR + Other Income - Vacancy Loss - Credit Loss", language="text")
            df = dataclass_rows(revenue[: max_month + 1]).drop(columns=["unit_type_detail"], errors="ignore")
            st.dataframe(df, hide_index=True, width="stretch")
        with t_unit:
            st.dataframe(flatten_unit_detail(revenue, max_month), hide_index=True, width="stretch")
        with t_opex:
            st.code("NOI = EGI - total OpEx", language="text")
            st.dataframe(dataclass_rows(opex[: max_month + 1]), hide_index=True, width="stretch")
        with t_capex:
            st.code("S-curve draw = total renovation budget × incremental draw percentage", language="text")
            st.dataframe(dataclass_rows(capex[: max_month + 1]), hide_index=True, width="stretch")
        with t_debt:
            st.code("Debt service = scheduled acquisition + refi payments. Construction interest is capitalized.", language="text")
            debt_df = dataclass_rows(debt[: max_month + 1])
            st.dataframe(debt_df.drop(columns=["acq_loan", "const_loan", "refi_loan"], errors="ignore"), hide_index=True, width="stretch")
        with t_dcf:
            st.code("Equity CF = NCFBT + refi proceeds + sale proceeds - GP fee - equity reno - initial equity", language="text")
            st.dataframe(dataclass_rows(cashflows[: max_month + 1]), hide_index=True, width="stretch")

    with main_tabs[5]:
        st.subheader("Audit Notes")
        st.success("Current baseline: engine runs, 43 tests pass, unlevered IRR includes terminal sale proceeds, and IRR helper has underflow guardrails.")
        st.markdown("""
**Known design choices**
- Workbench v2 is for model diagnosis, not final UX.
- Formula drawer is selected/click-based. True hover cards require custom front-end work later.
- Assumption intelligence currently uses simple one-variable shocks. Later versions should support market data links, input provenance, and saved assumption history.
- Waterfall logic is still simplified and should be upgraded before fund-level reporting.

**Next build targets**
1. Make formula explorer nodes clickable.
2. Add editable assumption source/confidence tags.
3. Save scenario results to a local database.
4. Add deal versioning and audit log.
""")
