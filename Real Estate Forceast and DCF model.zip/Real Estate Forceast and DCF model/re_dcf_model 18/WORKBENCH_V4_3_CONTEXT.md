# WORKBENCH V4.3 CONTEXT

Analyst Workbench patch release.

Fixes:
- Fixed nested sidebar navigation bug where submenu buttons appeared outside the expander and left empty containers.
- Deal Workspace, Analysis, and System menus now render their submenu buttons inside the relevant expander.
- Engine math unchanged.
- 43 tests passing.
