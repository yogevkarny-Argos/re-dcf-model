"""
Debug Workbench for the RE DCF engine.

Purpose: a local test interface for reviewing each engine's inputs, intermediate math,
and outputs before building the real UX/database layer.

Run:
    pip install -r requirements_debug.txt
    streamlit run debug_workbench_app.py
"""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Dict, List

import pandas as pd
import streamlit as st

from tests.fixtures import make_test_deal
from engine.assumptions import AbsorptionCurve
from engine.revenue import compute_revenue, get_stabilization_month
from engine.opex import compute_opex
from engine.capex import compute_capex
from engine.debt import compute_debt
from engine.dcf import build_cash_flows, compute_irr, compute_npv
from engine.waterfall import allocate_waterfall
from engine.kpis import compute_kpis


# -----------------------------
# Formatting helpers
# -----------------------------

def money(x: Any) -> str:
    if x is None:
        return "—"
    try:
        x = float(x)
    except Exception:
        return str(x)
    sign = "-" if x < 0 else ""
    x = abs(x)
    if x >= 1_000_000:
        return f"{sign}${x/1_000_000:,.2f}M"
    if x >= 1_000:
        return f"{sign}${x/1_000:,.0f}K"
    return f"{sign}${x:,.0f}"


def pct(x: Any) -> str:
    if x is None:
        return "—"
    try:
        return f"{float(x) * 100:,.2f}%"
    except Exception:
        return str(x)


def xmult(x: Any) -> str:
    if x is None:
        return "—"
    try:
        return f"{float(x):,.2f}x"
    except Exception:
        return str(x)


def dataclass_rows(objs: List[Any]) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for obj in objs:
        if is_dataclass(obj):
            rows.append(asdict(obj))
        elif isinstance(obj, dict):
            rows.append(obj)
        else:
            rows.append(getattr(obj, "__dict__", {"value": obj}))
    return pd.DataFrame(rows)


def flatten_unit_detail(revenue_months, max_month: int) -> pd.DataFrame:
    rows = []
    for r in revenue_months[: max_month + 1]:
        for d in r.unit_type_detail:
            row = asdict(d)
            row["month"] = r.month
            rows.append(row)
    return pd.DataFrame(rows)


# -----------------------------
# Assumption editor
# -----------------------------

def build_assumptions_from_ui():
    a = make_test_deal()

    st.sidebar.header("Deal")
    a.acquisition.purchase_price = st.sidebar.number_input(
        "Purchase price", min_value=1_000_000, max_value=500_000_000,
        value=int(a.acquisition.purchase_price), step=250_000,
    )
    a.timeline.hold_months = st.sidebar.slider("Hold months", 12, 120, a.timeline.hold_months, 6)
    a.exit.exit_month = a.timeline.hold_months
    a.discount_rate = st.sidebar.slider("Discount rate", 0.00, 0.25, a.discount_rate, 0.005)

    st.sidebar.header("Unit Mix / Revenue")
    rent_growth = st.sidebar.slider("Default rent growth", 0.00, 0.10, 0.03, 0.0025)
    stab_threshold = st.sidebar.slider("Stabilization occupancy threshold", 0.70, 0.99, a.timeline.stabilized_occ_threshold, 0.01)
    a.timeline.stabilized_occ_threshold = stab_threshold
    a.timeline.stability_confirmation_months = st.sidebar.slider("Stability confirmation months", 1, 6, a.timeline.stability_confirmation_months, 1)

    selected_curve = st.sidebar.selectbox(
        "Default absorption curve", [c.value for c in AbsorptionCurve], index=0
    )
    for ut in a.property.unit_types:
        ut.default_rent_growth = rent_growth
        ut.absorption_curve = AbsorptionCurve(selected_curve)

    with st.sidebar.expander("1BR quick edit", expanded=False):
        # Keep this intentionally narrow. This is a workbench, not final UX.
        one_br = next((u for u in a.property.unit_types if u.label == "1BR"), a.property.unit_types[0])
        one_br.in_place_rent = st.number_input("1BR in-place rent", 500, 5000, int(one_br.in_place_rent), 25)
        one_br.market_rent = st.number_input("1BR market rent", 500, 6000, int(one_br.market_rent), 25)
        one_br.in_place_occupancy = st.slider("1BR in-place occupancy", 0.50, 1.00, one_br.in_place_occupancy, 0.01)
        one_br.stabilized_occupancy = st.slider("1BR stabilized occupancy", 0.50, 1.00, one_br.stabilized_occupancy, 0.01)
        one_br.absorption_period_months = st.slider("1BR absorption months", 1, 48, one_br.absorption_period_months, 1)
        one_br.concession_weeks = st.slider("1BR concession weeks", 0.0, 12.0, float(one_br.concession_weeks), 0.5)

    st.sidebar.header("Renovation / CapEx")
    a.renovation.include_renovation = st.sidebar.checkbox("Include renovation", a.renovation.include_renovation)
    a.renovation.hard_cost_per_unit = st.sidebar.number_input("Hard cost / unit", 0, 100_000, int(a.renovation.hard_cost_per_unit), 500)
    a.renovation.contingency_pct = st.sidebar.slider("Contingency", 0.00, 0.40, a.renovation.contingency_pct, 0.01)
    a.renovation.reno_period_months = st.sidebar.slider("Reno period months", 1, 60, a.renovation.reno_period_months, 1)
    a.renovation.common_area_cost = st.sidebar.number_input("Common area cost", 0, 10_000_000, int(a.renovation.common_area_cost), 50_000)
    a.renovation.exterior_cost = st.sidebar.number_input("Exterior cost", 0, 10_000_000, int(a.renovation.exterior_cost), 50_000)

    st.sidebar.header("Debt")
    a.acq_loan.include = st.sidebar.checkbox("Include acquisition loan", a.acq_loan.include)
    a.acq_loan.ltv_or_ltc = st.sidebar.slider("Acq loan LTV", 0.00, 0.90, a.acq_loan.ltv_or_ltc, 0.01)
    a.acq_loan.interest_rate = st.sidebar.slider("Acq loan rate", 0.00, 0.15, a.acq_loan.interest_rate, 0.0025)
    a.acq_loan.io_period_months = st.sidebar.slider("Acq IO months", 0, 60, a.acq_loan.io_period_months, 6)

    a.const_loan.include = st.sidebar.checkbox("Include construction loan", a.const_loan.include)
    a.const_loan.max_commitment_pct_of_cost = st.sidebar.slider("Construction LTC on reno cost", 0.00, 1.00, a.const_loan.max_commitment_pct_of_cost, 0.01)
    a.const_loan.interest_rate = st.sidebar.slider("Construction loan rate", 0.00, 0.18, a.const_loan.interest_rate, 0.0025)

    a.refi.include = st.sidebar.checkbox("Include refi", a.refi.include)
    refi_trigger = st.sidebar.slider("Refi trigger month", 1, max(1, a.timeline.hold_months - 1), a.refi.trigger_month or 24, 1)
    a.refi.trigger_month = refi_trigger
    a.refi.ltv = st.sidebar.slider("Refi LTV", 0.00, 0.85, a.refi.ltv, 0.01)
    a.refi.interest_rate = st.sidebar.slider("Refi rate", 0.00, 0.15, a.refi.interest_rate, 0.0025)

    st.sidebar.header("Exit")
    a.exit.exit_cap_rate = st.sidebar.slider("Exit cap rate", 0.02, 0.12, a.exit.exit_cap_rate, 0.00125)
    a.exit.selling_cost_pct = st.sidebar.slider("Selling cost", 0.00, 0.08, a.exit.selling_cost_pct, 0.0025)
    a.market.market_cap_rate_going_in = st.sidebar.slider("Market cap for refi sizing", 0.02, 0.12, a.market.market_cap_rate_going_in, 0.00125)

    st.sidebar.header("OpEx")
    a.opex.repairs_maintenance.cost_per_unit_per_year = st.sidebar.number_input("R&M / unit / year", 0, 5000, int(a.opex.repairs_maintenance.cost_per_unit_per_year), 25)
    a.opex.payroll.cost_per_unit_per_year = st.sidebar.number_input("Payroll / unit / year", 0, 8000, int(a.opex.payroll.cost_per_unit_per_year), 25)
    a.opex.property_tax.cost_per_unit_per_year = st.sidebar.number_input("Tax / unit / year", 0, 10000, int(a.opex.property_tax.cost_per_unit_per_year), 25)
    a.opex.management_fee.pct_of_egi = st.sidebar.slider("Management fee % EGI", 0.00, 0.10, a.opex.management_fee.pct_of_egi, 0.0025)
    a.opex.reserves.cost_per_unit_per_year = st.sidebar.number_input("Reserves / unit / year", 0, 2000, int(a.opex.reserves.cost_per_unit_per_year), 25)

    return a


def run_all_engines(a):
    rev = compute_revenue(a)
    stab_m = get_stabilization_month(rev)
    egi_series = [r.egi for r in rev]
    opex = compute_opex(a, egi_series)
    noi_series = [o.noi for o in opex]
    capex = compute_capex(a, stabilization_month=stab_m)
    const_draws = [c.const_loan_draw for c in capex]
    debt = compute_debt(a, const_draws, stab_m, noi_series)
    cfs = build_cash_flows(rev, opex, capex, debt, a, stab_m)
    wf = allocate_waterfall([cf.equity_cf for cf in cfs], a)
    kpis = compute_kpis(cfs, debt, opex, rev, a, stab_m, wf)
    return rev, stab_m, opex, capex, debt, cfs, wf, kpis


# -----------------------------
# Page
# -----------------------------

st.set_page_config(page_title="RE DCF Engine Workbench", layout="wide")
st.title("RE DCF Engine Debug Workbench")
st.caption("Temporary test interface. Purpose: inspect module math before production UX/database work.")

try:
    assumptions = build_assumptions_from_ui()
    revenue, stab_month, opex, capex, debt, cashflows, waterfall, kpis = run_all_engines(assumptions)
except Exception as exc:
    st.error("Engine run failed.")
    st.exception(exc)
    st.stop()

# KPI header
cols = st.columns(8)
cols[0].metric("Levered IRR", pct(kpis.levered_irr))
cols[1].metric("Unlevered IRR", pct(kpis.unlevered_irr))
cols[2].metric("Equity Multiple", xmult(kpis.equity_multiple))
cols[3].metric("NPV", money(kpis.npv))
cols[4].metric("Yield on Cost", pct(kpis.yield_on_cost))
cols[5].metric("Dev Spread", f"{kpis.development_spread_bps:,.0f} bps")
cols[6].metric("DSCR Stab", xmult(kpis.dscr_stabilized))
cols[7].metric("Stab Month", str(kpis.stabilization_month))

st.divider()

max_month = st.slider("Display months", 12, assumptions.timeline.hold_months, min(36, assumptions.timeline.hold_months), 1)

summary_rows = [
    {"Engine": "Revenue", "Core math": "GPR + other income - credit/vacancy = EGI", "Primary output": f"Month {max_month} EGI {money(revenue[max_month].egi)}"},
    {"Engine": "OpEx", "Core math": "EGI - line-item expenses = NOI", "Primary output": f"Month {max_month} NOI {money(opex[max_month].noi)}"},
    {"Engine": "CapEx", "Core math": "S-curve draw × hard/soft/common cost; split debt vs equity", "Primary output": f"Total reno draw through m{max_month}: {money(sum(c.total_reno_draw for c in capex[:max_month+1]))}"},
    {"Engine": "Debt", "Core math": "Acq + construction + refi schedules; payoffs handled separately", "Primary output": f"Month {max_month} debt service {money(debt[max_month].total_debt_service)}"},
    {"Engine": "DCF", "Core math": "NOI - DS - capex + refi + sale - fees - initial equity", "Primary output": f"Month {max_month} equity CF {money(cashflows[max_month].equity_cf)}"},
    {"Engine": "KPIs", "Core math": "IRR, NPV, EM, cap rates, YoC, DSCR, payback", "Primary output": f"Levered IRR {pct(kpis.levered_irr)}"},
]
st.subheader("Engine Map")
st.dataframe(pd.DataFrame(summary_rows), use_container_width=True, hide_index=True)

# Formula audit notes
with st.expander("Formula notes / known audit points", expanded=True):
    st.markdown(
        """
- **Revenue:** unit-type cohort model. Unrenovated and renovated cohorts are calculated separately.
- **CapEx:** renovation draw uses `3t² - 2t³` S-curve unless custom schedule is used.
- **Debt:** construction interest is capitalized. Refi proceeds are capped at zero if refi amount does not exceed payoff/costs.
- **DCF:** levered sale proceeds are included in `sale_proceeds` and `equity_cf`.
- **Review item:** unlevered cash flow currently uses `NOI - total_reno_draw - ongoing`, with acquisition outflow at month 0. Verify whether unlevered terminal sale proceeds should be added for the intended KPI definition.
        """
    )

# Tabs per engine
revenue_tab, opex_tab, capex_tab, debt_tab, dcf_tab, waterfall_tab, assumptions_tab = st.tabs(
    ["Revenue", "OpEx", "CapEx", "Debt", "DCF", "Waterfall", "Assumptions"]
)

with revenue_tab:
    st.subheader("Revenue engine")
    st.code(
        "EGI = GPR + Other Income - Vacancy Loss - Credit Loss\n"
        "Renovated occupancy = in_place_occ + (stabilized_occ - in_place_occ) × absorption_curve(months_since_available)",
        language="text",
    )
    rev_df = dataclass_rows(revenue[: max_month + 1])
    st.dataframe(rev_df.drop(columns=["unit_type_detail"], errors="ignore"), use_container_width=True, hide_index=True)
    st.markdown("Unit-type cohort detail")
    st.dataframe(flatten_unit_detail(revenue, max_month), use_container_width=True, hide_index=True)

with opex_tab:
    st.subheader("OpEx engine")
    st.code(
        "Line cost = cost_per_unit_per_year × units / 12 × (1 + escalator/12)^month\n"
        "Management fee = EGI × pct_of_egi\n"
        "NOI = EGI - total OpEx",
        language="text",
    )
    st.dataframe(dataclass_rows(opex[: max_month + 1]), use_container_width=True, hide_index=True)

with capex_tab:
    st.subheader("CapEx engine")
    st.code(
        "S-curve cumulative fraction = 3t² - 2t³\n"
        "Monthly draw = total renovation cost × (cum_pct_this_month - cum_pct_prior_month)\n"
        "Construction loan draw = monthly draw × construction LTC\n"
        "Equity reno draw = monthly draw - construction loan draw",
        language="text",
    )
    st.dataframe(dataclass_rows(capex[: max_month + 1]), use_container_width=True, hide_index=True)

with debt_tab:
    st.subheader("Debt engine")
    st.code(
        "Acq loan amount = purchase price × LTV\n"
        "Construction loan interest = beginning balance × monthly rate, capitalized into ending balance\n"
        "Refi value = annualized NOI at refi month / market cap rate\n"
        "Refi amount = refi value × refi LTV\n"
        "Refi net proceeds = refi amount - acq payoff - construction payoff - refi costs",
        language="text",
    )
    debt_df = dataclass_rows(debt[: max_month + 1])
    st.dataframe(debt_df, use_container_width=True, hide_index=True)

with dcf_tab:
    st.subheader("DCF engine")
    st.code(
        "NCFBT = NOI - debt service - ongoing capex\n"
        "Equity CF = NCFBT + refi proceeds + sale proceeds - GP management fee - equity reno draw - initial equity\n"
        "Unlevered CF = NOI - total reno draw - ongoing capex - acquisition outflow at m0",
        language="text",
    )
    cf_df = dataclass_rows(cashflows[: max_month + 1])
    st.dataframe(cf_df, use_container_width=True, hide_index=True)
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("Levered IRR input stream")
        st.line_chart(pd.DataFrame({"equity_cf": [c.equity_cf for c in cashflows]}))
    with c2:
        st.markdown("Unlevered IRR input stream")
        st.line_chart(pd.DataFrame({"unlevered_cf": [c.unlevered_cf for c in cashflows]}))

with waterfall_tab:
    st.subheader("Waterfall engine")
    st.write("This is currently simplified. Use this only as a placeholder until monthly capital-account waterfall logic is designed.")
    st.json(asdict(waterfall))

with assumptions_tab:
    st.subheader("Current assumptions object")
    st.json(asdict(assumptions))

st.caption("Debug workbench generated for local model testing. Do not treat as final UX.")
