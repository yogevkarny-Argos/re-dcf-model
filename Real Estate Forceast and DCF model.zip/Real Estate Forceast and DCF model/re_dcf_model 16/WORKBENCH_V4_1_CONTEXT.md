# Workbench v4.1 Contextual UX

Changes:
- Scenario Lab now explains that recipe figures are auto-generated from current live assumptions.
- Added recipe definition table showing each scenario override logic.
- Deal Workspace Revenue section now contains real revenue build metrics and unit-type table.
- Sidebar now includes a context-aware Relevant Assumptions panel based on active workspace / deal section.
- Engine math unchanged.
