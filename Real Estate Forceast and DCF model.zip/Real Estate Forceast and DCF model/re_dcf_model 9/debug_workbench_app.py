"""
RE DCF Workbench v3.1

Purpose:
- Diagnostic underwriting interface, not client-facing UX.
- Exposes assumptions, formulas, source tags, dependency logic, cash-flow streams,
  scenario recipes, and KPI bridges.

Run:
    python3 -m pip install -r requirements_debug.txt
    python3 -m streamlit run debug_workbench_app.py
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, is_dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
import json
import sqlite3

import pandas as pd
import streamlit as st

from tests.fixtures import make_test_deal
from engine.assumptions import AbsorptionCurve
from engine.revenue import compute_revenue, get_stabilization_month
from engine.opex import compute_opex
from engine.capex import compute_capex
from engine.debt import compute_debt
from engine.dcf import build_cash_flows, compute_irr, compute_npv
from engine.waterfall import allocate_waterfall
from engine.kpis import compute_kpis


# =============================================================================
# Formatting helpers
# =============================================================================

def money(x: Any) -> str:
    if x is None:
        return "—"
    try:
        x = float(x)
    except Exception:
        return str(x)
    sign = "-" if x < 0 else ""
    x = abs(x)
    if x >= 1_000_000:
        return f"{sign}${x/1_000_000:,.2f}M"
    if x >= 1_000:
        return f"{sign}${x/1_000:,.0f}K"
    return f"{sign}${x:,.0f}"


def pct(x: Any) -> str:
    if x is None:
        return "—"
    try:
        return f"{float(x) * 100:,.2f}%"
    except Exception:
        return str(x)


def xmult(x: Any) -> str:
    if x is None:
        return "—"
    try:
        return f"{float(x):,.2f}x"
    except Exception:
        return str(x)


def safe_float(x: Any) -> Optional[float]:
    try:
        return float(x)
    except Exception:
        return None


def dataclass_rows(objs: List[Any]) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for obj in objs:
        if is_dataclass(obj):
            rows.append(asdict(obj))
        elif isinstance(obj, dict):
            rows.append(obj)
        else:
            rows.append(getattr(obj, "__dict__", {"value": obj}))
    return pd.DataFrame(rows)


def flatten_unit_detail(revenue_months, max_month: int) -> pd.DataFrame:
    rows = []
    for r in revenue_months[: max_month + 1]:
        for d in r.unit_type_detail:
            row = asdict(d)
            row["month"] = r.month
            rows.append(row)
    return pd.DataFrame(rows)


# =============================================================================
# Engine runner
# =============================================================================

def run_all_engines(a):
    rev = compute_revenue(a)
    stab_m = get_stabilization_month(rev)
    egi_series = [r.egi for r in rev]
    opex = compute_opex(a, egi_series)
    noi_series = [o.noi for o in opex]
    capex = compute_capex(a, stabilization_month=stab_m)
    const_draws = [c.const_loan_draw for c in capex]
    debt = compute_debt(a, const_draws, stab_m, noi_series)
    cfs = build_cash_flows(rev, opex, capex, debt, a, stab_m)
    wf = allocate_waterfall([cf.equity_cf for cf in cfs], a)
    kpis = compute_kpis(cfs, debt, opex, rev, a, stab_m, wf)
    return rev, stab_m, opex, capex, debt, cfs, wf, kpis


def run_kpis_only(a):
    try:
        *_, kpis = run_all_engines(a)
        return kpis
    except Exception:
        return None


# =============================================================================
# Assumption editor
# =============================================================================

def build_assumptions_from_ui():
    a = make_test_deal()

    st.sidebar.header("Deal")
    a.acquisition.purchase_price = st.sidebar.number_input(
        "Purchase price", min_value=1_000_000, max_value=500_000_000,
        value=int(a.acquisition.purchase_price), step=250_000,
    )
    a.timeline.hold_months = st.sidebar.slider("Hold months", 12, 120, a.timeline.hold_months, 6)
    a.exit.exit_month = a.timeline.hold_months
    a.discount_rate = st.sidebar.slider("Discount rate", 0.00, 0.25, a.discount_rate, 0.005)

    st.sidebar.header("Revenue / Lease-Up")
    rent_growth = st.sidebar.slider("Default rent growth", 0.00, 0.10, 0.03, 0.0025)
    stab_threshold = st.sidebar.slider(
        "Stabilization occupancy threshold", 0.70, 0.99,
        a.timeline.stabilized_occ_threshold, 0.01,
    )
    a.timeline.stabilized_occ_threshold = stab_threshold
    a.timeline.stability_confirmation_months = st.sidebar.slider(
        "Stability confirmation months", 1, 6, a.timeline.stability_confirmation_months, 1,
    )

    selected_curve = st.sidebar.selectbox(
        "Default absorption curve", [c.value for c in AbsorptionCurve], index=0,
    )
    for ut in a.property.unit_types:
        ut.default_rent_growth = rent_growth
        ut.absorption_curve = AbsorptionCurve(selected_curve)

    with st.sidebar.expander("1BR quick edit", expanded=False):
        one_br = next((u for u in a.property.unit_types if u.label == "1BR"), a.property.unit_types[0])
        one_br.in_place_rent = st.number_input("1BR in-place rent", 500, 5000, int(one_br.in_place_rent), 25)
        one_br.market_rent = st.number_input("1BR market rent", 500, 6000, int(one_br.market_rent), 25)
        one_br.in_place_occupancy = st.slider("1BR in-place occupancy", 0.50, 1.00, float(one_br.in_place_occupancy), 0.01)
        one_br.stabilized_occupancy = st.slider("1BR stabilized occupancy", 0.50, 1.00, float(one_br.stabilized_occupancy), 0.01)
        one_br.absorption_period_months = st.slider("1BR absorption months", 1, 48, int(one_br.absorption_period_months), 1)
        one_br.concession_weeks = st.slider("1BR concession weeks", 0.0, 12.0, float(one_br.concession_weeks), 0.5)

    st.sidebar.header("Renovation / CapEx")
    a.renovation.include_renovation = st.sidebar.checkbox("Include renovation", a.renovation.include_renovation)
    a.renovation.hard_cost_per_unit = st.sidebar.number_input("Hard cost / unit", 0, 100_000, int(a.renovation.hard_cost_per_unit), 500)
    a.renovation.contingency_pct = st.sidebar.slider("Contingency", 0.00, 0.40, a.renovation.contingency_pct, 0.01)
    a.renovation.reno_period_months = st.sidebar.slider("Reno period months", 1, 60, a.renovation.reno_period_months, 1)
    a.renovation.common_area_cost = st.sidebar.number_input("Common area cost", 0, 10_000_000, int(a.renovation.common_area_cost), 50_000)
    a.renovation.exterior_cost = st.sidebar.number_input("Exterior cost", 0, 10_000_000, int(a.renovation.exterior_cost), 50_000)

    st.sidebar.header("Debt")
    a.acq_loan.include = st.sidebar.checkbox("Include acquisition loan", a.acq_loan.include)
    a.acq_loan.ltv_or_ltc = st.sidebar.slider("Acq loan LTV", 0.00, 0.90, a.acq_loan.ltv_or_ltc, 0.01)
    a.acq_loan.interest_rate = st.sidebar.slider("Acq loan rate", 0.00, 0.15, a.acq_loan.interest_rate, 0.0025)
    a.acq_loan.io_period_months = st.sidebar.slider("Acq IO months", 0, 60, a.acq_loan.io_period_months, 6)

    a.const_loan.include = st.sidebar.checkbox("Include construction loan", a.const_loan.include)
    a.const_loan.max_commitment_pct_of_cost = st.sidebar.slider("Construction LTC on reno cost", 0.00, 1.00, a.const_loan.max_commitment_pct_of_cost, 0.01)
    a.const_loan.interest_rate = st.sidebar.slider("Construction loan rate", 0.00, 0.18, a.const_loan.interest_rate, 0.0025)

    a.refi.include = st.sidebar.checkbox("Include refi", a.refi.include)
    refi_trigger = st.sidebar.slider("Refi trigger month", 1, max(1, a.timeline.hold_months - 1), a.refi.trigger_month or 24, 1)
    a.refi.trigger_month = refi_trigger
    a.refi.ltv = st.sidebar.slider("Refi LTV", 0.00, 0.85, a.refi.ltv, 0.01)
    a.refi.interest_rate = st.sidebar.slider("Refi rate", 0.00, 0.15, a.refi.interest_rate, 0.0025)

    st.sidebar.header("Exit")
    a.exit.exit_cap_rate = st.sidebar.slider("Exit cap rate", 0.02, 0.12, a.exit.exit_cap_rate, 0.00125)
    a.exit.selling_cost_pct = st.sidebar.slider("Selling cost", 0.00, 0.08, a.exit.selling_cost_pct, 0.0025)
    a.market.market_cap_rate_going_in = st.sidebar.slider("Market cap for refi sizing", 0.02, 0.12, a.market.market_cap_rate_going_in, 0.00125)

    st.sidebar.header("OpEx")
    a.opex.repairs_maintenance.cost_per_unit_per_year = st.sidebar.number_input("R&M / unit / year", 0, 5000, int(a.opex.repairs_maintenance.cost_per_unit_per_year), 25)
    a.opex.payroll.cost_per_unit_per_year = st.sidebar.number_input("Payroll / unit / year", 0, 8000, int(a.opex.payroll.cost_per_unit_per_year), 25)
    a.opex.property_tax.cost_per_unit_per_year = st.sidebar.number_input("Tax / unit / year", 0, 10000, int(a.opex.property_tax.cost_per_unit_per_year), 25)
    a.opex.management_fee.pct_of_egi = st.sidebar.slider("Management fee % EGI", 0.00, 0.10, a.opex.management_fee.pct_of_egi, 0.0025)
    a.opex.reserves.cost_per_unit_per_year = st.sidebar.number_input("Reserves / unit / year", 0, 2000, int(a.opex.reserves.cost_per_unit_per_year), 25)

    return a


# =============================================================================
# Formula / source intelligence
# =============================================================================

def kpi_values(kpis) -> Dict[str, Any]:
    return {
        "Levered IRR": kpis.levered_irr,
        "Unlevered IRR": kpis.unlevered_irr,
        "Equity Multiple": kpis.equity_multiple,
        "NPV": kpis.npv,
        "Yield on Cost": kpis.yield_on_cost,
        "Development Spread": kpis.development_spread_bps,
        "DSCR Stabilized": kpis.dscr_stabilized,
        "Stabilization Month": kpis.stabilization_month,
    }


def formula_dictionary(a, cashflows, debt, opex, kpis) -> Dict[str, Dict[str, Any]]:
    exit_m = a.exit.exit_month
    exit_cf = cashflows[exit_m]
    exit_noi = exit_cf.noi * 12
    gross_exit_value = exit_noi / a.exit.exit_cap_rate if a.exit.exit_cap_rate > 0 else 0.0
    levered_cfs = [cf.equity_cf for cf in cashflows]
    unlevered_cfs = [cf.unlevered_cf for cf in cashflows]

    total_in = sum(-c for c in levered_cfs if c < 0)
    total_out = sum(c for c in levered_cfs if c > 0)

    return {
        "Levered IRR": {
            "definition": "Annualized internal rate of return on the equity cash-flow stream.",
            "formula": "IRR([equity_cf_month_0 ... equity_cf_exit]) annualized as (1 + monthly_irr)^12 - 1",
            "source": "engine.kpis.compute_kpis → engine.dcf.compute_irr(equity_cfs)",
            "inputs": ["equity_cf", "NOI", "debt_service", "refi_proceeds", "sale_proceeds", "equity-funded capex", "initial equity"],
            "current": pct(kpis.levered_irr),
            "bridge": [
                {"Component": "Initial equity outflow", "Value": money(cashflows[0].equity_cf)},
                {"Component": "Total positive equity CF", "Value": money(total_out)},
                {"Component": "Total negative equity CF", "Value": money(-total_in)},
                {"Component": "Exit month equity CF", "Value": money(exit_cf.equity_cf)},
            ],
            "cashflows": levered_cfs,
        },
        "Unlevered IRR": {
            "definition": "Property-level IRR before debt. Includes acquisition, property NOI, total renovation draws, ongoing reserves, and unlevered terminal sale proceeds.",
            "formula": "IRR(NOI - total_reno_draw - ongoing_capex + unlevered_sale_proceeds - acquisition_outflow at month 0)",
            "source": "engine.dcf.build_cash_flows → CashFlowMonth.unlevered_cf → compute_irr",
            "inputs": ["purchase price", "closing costs", "NOI", "total renovation draw", "ongoing capex", "gross exit value", "selling cost", "disposition fee"],
            "current": pct(kpis.unlevered_irr),
            "bridge": [
                {"Component": "Month 0 unlevered CF", "Value": money(cashflows[0].unlevered_cf)},
                {"Component": "Exit month unlevered CF", "Value": money(exit_cf.unlevered_cf)},
                {"Component": "Total positive unlevered CF", "Value": money(sum(x for x in unlevered_cfs if x > 0))},
                {"Component": "Total negative unlevered CF", "Value": money(sum(x for x in unlevered_cfs if x < 0))},
            ],
            "cashflows": unlevered_cfs,
        },
        "Exit Value": {
            "definition": "Terminal property value before debt payoff, based on exit NOI and exit cap rate.",
            "formula": "Exit Value = Exit Month NOI × 12 / Exit Cap Rate",
            "source": "engine.dcf.build_cash_flows and engine.kpis.compute_kpis",
            "inputs": ["exit month NOI", "exit cap rate"],
            "current": money(gross_exit_value),
            "bridge": [
                {"Component": "Exit monthly NOI", "Value": money(exit_cf.noi)},
                {"Component": "Exit annualized NOI", "Value": money(exit_noi)},
                {"Component": "Exit cap rate", "Value": pct(a.exit.exit_cap_rate)},
                {"Component": "Gross exit value", "Value": money(gross_exit_value)},
                {"Component": "Levered net sale proceeds", "Value": money(exit_cf.sale_proceeds)},
            ],
            "cashflows": [],
        },
        "Refi Proceeds": {
            "definition": "Net cash proceeds from refinance after paying off acquisition/construction debt and refi costs.",
            "formula": "Refi Loan = Stabilized Value × Refi LTV; Net Proceeds = Refi Loan - Payoffs - Costs, floored at zero",
            "source": "engine.debt.compute_debt",
            "inputs": ["NOI at refi", "market cap rate", "refi LTV", "acquisition payoff", "construction payoff", "refi costs"],
            "current": money(sum(cf.refi_proceeds for cf in cashflows)),
            "bridge": [
                {"Component": "Total refi proceeds", "Value": money(sum(cf.refi_proceeds for cf in cashflows))},
                {"Component": "Refi LTV", "Value": pct(a.refi.ltv)},
                {"Component": "Market cap for sizing", "Value": pct(a.market.market_cap_rate_going_in)},
            ],
            "cashflows": [cf.refi_proceeds for cf in cashflows],
        },
        "DSCR Stabilized": {
            "definition": "Annualized NOI at stabilization divided by annualized debt service at stabilization.",
            "formula": "DSCR = Stabilized NOI × 12 / Stabilized Debt Service × 12",
            "source": "engine.kpis.compute_kpis",
            "inputs": ["stabilization month", "NOI", "total debt service"],
            "current": xmult(kpis.dscr_stabilized),
            "bridge": [
                {"Component": "Stabilization month", "Value": str(kpis.stabilization_month)},
                {"Component": "Monthly NOI at stabilization", "Value": money(opex[kpis.stabilization_month].noi)},
                {"Component": "Monthly debt service at stabilization", "Value": money(debt[kpis.stabilization_month].total_debt_service)},
                {"Component": "DSCR", "Value": xmult(kpis.dscr_stabilized)},
            ],
            "cashflows": [],
        },
    }



def cashflow_trace_table(cashflows, capex, debt, a) -> pd.DataFrame:
    """Month-level bridge that makes the DCF math inspectable."""
    rows = []
    pp = a.acquisition.purchase_price
    acq_costs = a.acquisition.total_closing_costs
    acq_loan_amt = pp * a.acq_loan.ltv_or_ltc if a.acq_loan.include else 0.0
    gp_fee = pp * a.waterfall.gp_acquisition_fee_pct
    exit_m = a.exit.exit_month

    for i, cf in enumerate(cashflows):
        cx = capex[i]
        dm = debt[i]
        initial_equity = (pp - acq_loan_amt) + acq_costs + gp_fee if cf.month == 0 else 0.0
        gp_mgmt_fee = cf.egi * a.waterfall.gp_asset_mgmt_fee_pct / 12.0
        total_reno_draw = getattr(cx, "total_reno_draw", 0.0)
        ongoing = getattr(cx, "ongoing_capex", 0.0)
        unlevered_sale = 0.0
        exit_value = 0.0
        gross_after_selling = 0.0
        disposition_fee = 0.0
        payoff = getattr(dm, "payoff_amount", 0.0)
        if cf.month == exit_m:
            exit_value = (cf.noi * 12.0) / a.exit.exit_cap_rate if a.exit.exit_cap_rate > 0 else 0.0
            gross_after_selling = exit_value * (1 - a.exit.selling_cost_pct)
            disposition_fee = exit_value * a.waterfall.gp_disposition_fee_pct
            unlevered_sale = gross_after_selling - disposition_fee
        rows.append({
            "month": cf.month,
            "EGI": cf.egi,
            "NOI": cf.noi,
            "Debt Service": cf.debt_service,
            "Ongoing CapEx": ongoing,
            "NCFBT = NOI - DS - Ongoing": cf.ncfbt,
            "Refi Proceeds": cf.refi_proceeds,
            "Exit Value": exit_value,
            "Gross After Selling Cost": gross_after_selling,
            "Loan Payoff": payoff,
            "Disposition Fee": disposition_fee,
            "Levered Sale Proceeds": cf.sale_proceeds,
            "GP Mgmt Fee": gp_mgmt_fee,
            "Equity Reno Draw": getattr(cx, "equity_reno_draw", 0.0),
            "Initial Equity Outflow": initial_equity,
            "Equity CF": cf.equity_cf,
            "Total Reno Draw": total_reno_draw,
            "Unlevered Sale Proceeds": unlevered_sale,
            "Unlevered CF": cf.unlevered_cf,
        })
    return pd.DataFrame(rows)


def build_formula_trace(a, revenue, opex, capex, debt, cashflows, kpis) -> Dict[str, Dict[str, Any]]:
    """Live trace layer. It does not change model math; it explains the math already produced."""
    trace_df = cashflow_trace_table(cashflows, capex, debt, a)
    exit_m = a.exit.exit_month
    stab_m = kpis.stabilization_month
    levered_cfs = [cf.equity_cf for cf in cashflows]
    unlevered_cfs = [cf.unlevered_cf for cf in cashflows]
    exit_row = trace_df.loc[trace_df["month"] == exit_m].iloc[0]
    stab_row = trace_df.loc[trace_df["month"] == stab_m].iloc[0]
    total_project_cost = (
        a.acquisition.purchase_price
        + a.acquisition.total_closing_costs
        + sum(getattr(c, "total_reno_draw", 0.0) for c in capex)
    )

    def bridge_rows(items):
        return pd.DataFrame([{"Component": k, "Value": v, "Formula Role": r} for k, v, r in items])

    return {
        "Levered IRR": {
            "value": pct(kpis.levered_irr),
            "source_function": "engine.kpis.compute_kpis → engine.dcf.compute_irr",
            "source_file": "engine/kpis.py lines around compute_kpis; engine/dcf.py compute_irr",
            "formula": "Levered IRR = annualized IRR(equity_cf[0:exit_month])",
            "dependencies": ["Equity CF", "NCFBT", "NOI", "Debt Service", "Refi Proceeds", "Levered Sale Proceeds", "Equity Reno Draw", "Initial Equity"],
            "bridge": bridge_rows([
                ("Month 0 Equity CF", money(levered_cfs[0]), "Initial equity outflow net of acquisition debt"),
                ("Total Positive Equity CF", money(sum(x for x in levered_cfs if x > 0)), "Cash returned before and at exit"),
                ("Total Negative Equity CF", money(sum(x for x in levered_cfs if x < 0)), "Equity invested and interim deficits"),
                ("Exit Month Equity CF", money(levered_cfs[exit_m]), "Terminal equity distribution"),
                ("Refi Proceeds", money(sum(cf.refi_proceeds for cf in cashflows)), "Mid-hold liquidity event"),
                ("Levered Sale Proceeds", money(exit_row["Levered Sale Proceeds"]), "Sale after debt payoff and fees"),
            ]),
            "month_detail": trace_df[["month", "NOI", "Debt Service", "NCFBT = NOI - DS - Ongoing", "Refi Proceeds", "Levered Sale Proceeds", "GP Mgmt Fee", "Equity Reno Draw", "Initial Equity Outflow", "Equity CF"]],
            "warnings": ["Multiple sign changes can create multiple IRR roots. Review the cash-flow stream if results look unintuitive."],
        },
        "Unlevered IRR": {
            "value": pct(kpis.unlevered_irr),
            "source_function": "engine.dcf.build_cash_flows → CashFlowMonth.unlevered_cf → engine.dcf.compute_irr",
            "source_file": "engine/dcf.py build_cash_flows and compute_irr",
            "formula": "Unlevered IRR = annualized IRR(NOI - total_reno_draw - ongoing_capex + unlevered_sale_proceeds - acquisition_outflow at m0)",
            "dependencies": ["Purchase Price", "Closing Costs", "NOI", "Total Reno Draw", "Ongoing CapEx", "Unlevered Sale Proceeds"],
            "bridge": bridge_rows([
                ("Month 0 Unlevered CF", money(unlevered_cfs[0]), "Purchase price + closing costs offset by month 0 NOI"),
                ("Total Positive Unlevered CF", money(sum(x for x in unlevered_cfs if x > 0)), "Operating cash flow and terminal property sale"),
                ("Total Negative Unlevered CF", money(sum(x for x in unlevered_cfs if x < 0)), "Acquisition and renovation draw periods"),
                ("Exit Month Unlevered CF", money(unlevered_cfs[exit_m]), "NOI plus unlevered sale proceeds"),
                ("Unlevered Sale Proceeds", money(exit_row["Unlevered Sale Proceeds"]), "Gross after selling cost less disposition fee, no debt payoff"),
            ]),
            "month_detail": trace_df[["month", "NOI", "Total Reno Draw", "Ongoing CapEx", "Unlevered Sale Proceeds", "Unlevered CF"]],
            "warnings": ["This metric must include terminal sale proceeds. Earlier build was fixed after this trace exposed the missing exit value."],
        },
        "Equity CF": {
            "value": money(sum(levered_cfs)),
            "source_function": "engine.dcf.build_cash_flows",
            "source_file": "engine/dcf.py CashFlowMonth.equity_cf",
            "formula": "Equity CF = NCFBT + refi proceeds + sale proceeds - GP mgmt fee - equity reno draw - initial equity outflow",
            "dependencies": ["NOI", "Debt Service", "Ongoing CapEx", "Refi Proceeds", "Sale Proceeds", "GP Fees", "Reno Equity", "Initial Equity"],
            "bridge": bridge_rows([
                ("NCFBT Total", money(sum(cf.ncfbt for cf in cashflows)), "NOI less debt service and ongoing capex"),
                ("Refi Proceeds", money(sum(cf.refi_proceeds for cf in cashflows)), "Refi cash inflow"),
                ("Levered Sale Proceeds", money(exit_row["Levered Sale Proceeds"]), "Terminal sale net of loan payoff"),
                ("Equity CF Net", money(sum(levered_cfs)), "Net sum of equity stream"),
            ]),
            "month_detail": trace_df[["month", "NCFBT = NOI - DS - Ongoing", "Refi Proceeds", "Levered Sale Proceeds", "GP Mgmt Fee", "Equity Reno Draw", "Initial Equity Outflow", "Equity CF"]],
            "warnings": [],
        },
        "NOI": {
            "value": money(stab_row["NOI"]),
            "source_function": "engine.opex.compute_opex",
            "source_file": "engine/opex.py compute_opex",
            "formula": "NOI = EGI - total operating expenses",
            "dependencies": ["Revenue", "Vacancy", "Credit Loss", "OpEx Lines", "Management Fee"],
            "bridge": bridge_rows([
                ("Stabilized EGI", money(stab_row["EGI"]), "Effective gross income at stabilization"),
                ("Stabilized NOI", money(stab_row["NOI"]), "Output after OpEx"),
                ("Annualized Stabilized NOI", money(stab_row["NOI"] * 12), "Used in cap rates and DSCR"),
            ]),
            "month_detail": pd.DataFrame([asdict(o) for o in opex]),
            "warnings": [],
        },
        "Exit Value": {
            "value": money(exit_row["Exit Value"]),
            "source_function": "engine.dcf.build_cash_flows; engine.kpis.compute_kpis",
            "source_file": "engine/dcf.py exit / sale proceeds block",
            "formula": "Exit Value = Exit Month NOI × 12 / Exit Cap Rate",
            "dependencies": ["Exit Month NOI", "Exit Cap Rate"],
            "bridge": bridge_rows([
                ("Exit Monthly NOI", money(exit_row["NOI"]), "Source NOI in exit month"),
                ("Exit Annual NOI", money(exit_row["NOI"] * 12), "Annualized terminal NOI"),
                ("Exit Cap Rate", pct(a.exit.exit_cap_rate), "Terminal valuation denominator"),
                ("Exit Value", money(exit_row["Exit Value"]), "Gross property value before costs"),
                ("Gross After Selling Cost", money(exit_row["Gross After Selling Cost"]), "Exit value less broker/selling costs"),
            ]),
            "month_detail": trace_df.loc[trace_df["month"].isin([max(0, exit_m-2), max(0, exit_m-1), exit_m]), ["month", "NOI", "Exit Value", "Gross After Selling Cost", "Loan Payoff", "Disposition Fee", "Levered Sale Proceeds"]],
            "warnings": ["Exit cap is typically one of the highest-impact assumptions."],
        },
        "Refi Proceeds": {
            "value": money(sum(cf.refi_proceeds for cf in cashflows)),
            "source_function": "engine.debt.compute_debt",
            "source_file": "engine/debt.py compute_debt",
            "formula": "Net Refi Proceeds = Refi Loan Amount - acquisition payoff - construction payoff - refi costs, floored at zero",
            "dependencies": ["Refi Month NOI", "Market Cap Rate", "Refi LTV", "Debt Payoffs", "Refi Costs"],
            "bridge": bridge_rows([
                ("Total Refi Proceeds", money(sum(cf.refi_proceeds for cf in cashflows)), "Cash released to equity at refi"),
                ("Refi LTV", pct(a.refi.ltv), "Debt sizing assumption"),
                ("Market Cap Rate", pct(a.market.market_cap_rate_going_in), "Valuation denominator for refi sizing"),
            ]),
            "month_detail": trace_df[["month", "NOI", "Debt Service", "Refi Proceeds", "Equity CF"]],
            "warnings": ["If refi proceeds are zero, check whether payoff amounts exceed available refi sizing."],
        },
        "DSCR Stabilized": {
            "value": xmult(kpis.dscr_stabilized),
            "source_function": "engine.kpis.compute_kpis",
            "source_file": "engine/kpis.py DSCR at stabilization block",
            "formula": "DSCR = stabilized NOI × 12 / stabilized debt service × 12",
            "dependencies": ["Stabilization Month", "NOI", "Debt Service"],
            "bridge": bridge_rows([
                ("Stabilization Month", str(stab_m), "First sustained occupancy threshold month"),
                ("Monthly NOI", money(stab_row["NOI"]), "Stabilized NOI"),
                ("Monthly Debt Service", money(stab_row["Debt Service"]), "Debt service at stabilization"),
                ("DSCR", xmult(kpis.dscr_stabilized), "NOI / debt service"),
            ]),
            "month_detail": trace_df[["month", "NOI", "Debt Service", "Equity CF"]],
            "warnings": [],
        },
        "Yield on Cost": {
            "value": pct(kpis.yield_on_cost),
            "source_function": "engine.kpis.compute_kpis",
            "source_file": "engine/kpis.py yield on cost block",
            "formula": "Yield on Cost = Stabilized Annual NOI / Total Project Cost",
            "dependencies": ["Stabilized NOI", "Purchase Price", "Closing Costs", "Renovation Costs"],
            "bridge": bridge_rows([
                ("Stabilized Annual NOI", money(stab_row["NOI"] * 12), "Numerator"),
                ("Total Project Cost", money(total_project_cost), "Denominator"),
                ("Yield on Cost", pct(kpis.yield_on_cost), "Output"),
            ]),
            "month_detail": trace_df[["month", "NOI", "Total Reno Draw", "Unlevered CF"]],
            "warnings": [],
        },
    }


def assumption_intelligence(a, base_kpis) -> pd.DataFrame:
    base_irr = safe_float(base_kpis.levered_irr) or 0.0
    rows = []

    def test_change(label: str, source: str, confidence: str, path: str, current: str, change_text: str, changer: Callable[[Any], None]):
        b = deepcopy(a)
        changer(b)
        k = run_kpis_only(b)
        new_irr = safe_float(k.levered_irr) if k else None
        delta = None if new_irr is None else new_irr - base_irr
        impact = "Unknown"
        if delta is not None:
            ad = abs(delta)
            if ad >= 0.015:
                impact = "Very High"
            elif ad >= 0.0075:
                impact = "High"
            elif ad >= 0.0025:
                impact = "Medium"
            else:
                impact = "Low"
        rows.append({
            "Assumption": label,
            "Current": current,
            "Source": source,
            "Confidence": confidence,
            "Tested Shock": change_text,
            "Levered IRR Impact": "—" if delta is None else f"{delta*100:+.2f} pts",
            "Impact Class": impact,
            "Model Path": path,
        })

    test_change(
        "Exit Cap Rate", "Manual / Market Comp", "Medium", "a.exit.exit_cap_rate", pct(a.exit.exit_cap_rate), "+25 bps",
        lambda b: setattr(b.exit, "exit_cap_rate", b.exit.exit_cap_rate + 0.0025),
    )
    test_change(
        "Rent Growth", "Manual / Market Rent Assumption", "Medium", "unit_type.default_rent_growth", pct(a.property.unit_types[0].default_rent_growth), "+50 bps",
        lambda b: [setattr(u, "default_rent_growth", u.default_rent_growth + 0.005) for u in b.property.unit_types],
    )
    test_change(
        "Hard Cost / Unit", "Manual / Renovation Budget", "Medium", "a.renovation.hard_cost_per_unit", money(a.renovation.hard_cost_per_unit), "+10%",
        lambda b: setattr(b.renovation, "hard_cost_per_unit", b.renovation.hard_cost_per_unit * 1.10),
    )
    test_change(
        "Refi Rate", "Manual / Debt Quote", "Medium", "a.refi.interest_rate", pct(a.refi.interest_rate), "+100 bps",
        lambda b: setattr(b.refi, "interest_rate", b.refi.interest_rate + 0.01),
    )
    test_change(
        "Refi LTV", "Manual / Debt Quote", "Low-Medium", "a.refi.ltv", pct(a.refi.ltv), "-5 pts",
        lambda b: setattr(b.refi, "ltv", max(0.0, b.refi.ltv - 0.05)),
    )
    return pd.DataFrame(rows)


def apply_scenario(a, recipe: str):
    b = deepcopy(a)
    if recipe == "Base":
        return b
    if recipe == "Exit Cap Expansion":
        b.exit.exit_cap_rate += 0.005
    elif recipe == "Cost Overrun":
        b.renovation.hard_cost_per_unit *= 1.15
        b.renovation.contingency_pct += 0.05
        b.renovation.reno_period_months += 3
    elif recipe == "Lease-Up Delay":
        for u in b.property.unit_types:
            u.absorption_period_months += 6
            u.concession_weeks += 2
    elif recipe == "Refi Failure":
        b.refi.include = False
    elif recipe == "Rate Shock":
        b.acq_loan.interest_rate += 0.01
        b.const_loan.interest_rate += 0.01
        b.refi.interest_rate += 0.01
    elif recipe == "Rent Recession":
        for u in b.property.unit_types:
            u.default_rent_growth = max(0.0, u.default_rent_growth - 0.015)
            u.stabilized_occupancy = max(0.80, u.stabilized_occupancy - 0.03)
    return b


# =============================================================================
# Local persistence: SQLite scenario results, deal versions, assumption metadata, audit log
# =============================================================================

DB_PATH = Path("workbench_local.db")


def json_default(obj):
    if is_dataclass(obj):
        return asdict(obj)
    if hasattr(obj, "value"):
        return obj.value
    try:
        return str(obj)
    except Exception:
        return None


def to_json(obj: Any) -> str:
    return json.dumps(obj, default=json_default, indent=2, sort_keys=True)


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def db_conn():
    return sqlite3.connect(DB_PATH)


def init_db() -> None:
    with db_conn() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS assumption_metadata (
                field_key TEXT PRIMARY KEY,
                display_name TEXT NOT NULL,
                source TEXT NOT NULL,
                confidence TEXT NOT NULL,
                note TEXT DEFAULT '',
                updated_at TEXT NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS scenario_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL,
                deal_name TEXT NOT NULL,
                scenario_name TEXT NOT NULL,
                levered_irr REAL,
                unlevered_irr REAL,
                npv REAL,
                equity_multiple REAL,
                irr_delta REAL,
                assumptions_json TEXT NOT NULL,
                kpis_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS deal_versions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                deal_name TEXT NOT NULL,
                version_label TEXT NOT NULL,
                assumptions_json TEXT NOT NULL,
                kpis_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                detail TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        con.commit()
    seed_assumption_metadata()


def append_audit(event_type: str, detail: str) -> None:
    with db_conn() as con:
        con.execute(
            "INSERT INTO audit_log(event_type, detail, created_at) VALUES (?, ?, ?)",
            (event_type, detail, now_iso()),
        )
        con.commit()


def default_assumption_metadata_rows() -> List[Dict[str, str]]:
    return [
        {"field_key": "acquisition.purchase_price", "display_name": "Purchase Price", "source": "Manual", "confidence": "Medium", "note": "Initial acquisition price assumption."},
        {"field_key": "timeline.hold_months", "display_name": "Hold Period", "source": "Manual", "confidence": "Medium", "note": "Investment hold period in months."},
        {"field_key": "exit.exit_cap_rate", "display_name": "Exit Cap Rate", "source": "Manual / Market Comp", "confidence": "Medium", "note": "High-impact terminal valuation assumption."},
        {"field_key": "market.market_cap_rate_going_in", "display_name": "Market Cap for Refi", "source": "Manual / Debt Sizing", "confidence": "Medium", "note": "Used to size stabilized/refi value."},
        {"field_key": "unit_type.default_rent_growth", "display_name": "Rent Growth", "source": "Manual / Market Assumption", "confidence": "Medium", "note": "Applied to unit types."},
        {"field_key": "timeline.stabilized_occ_threshold", "display_name": "Stabilization Occupancy", "source": "Manual", "confidence": "Medium", "note": "Used by stabilization detector."},
        {"field_key": "renovation.hard_cost_per_unit", "display_name": "Hard Cost / Unit", "source": "Manual / Budget", "confidence": "Medium", "note": "Reno budget driver."},
        {"field_key": "renovation.contingency_pct", "display_name": "Contingency", "source": "Manual / Budget", "confidence": "Medium", "note": "CapEx cushion."},
        {"field_key": "acq_loan.ltv_or_ltc", "display_name": "Acq Loan LTV", "source": "Manual / Debt Quote", "confidence": "Medium", "note": "Purchase debt sizing."},
        {"field_key": "acq_loan.interest_rate", "display_name": "Acq Loan Rate", "source": "Manual / Debt Quote", "confidence": "Medium", "note": "Debt-service driver."},
        {"field_key": "refi.ltv", "display_name": "Refi LTV", "source": "Manual / Debt Quote", "confidence": "Low-Medium", "note": "Refi proceeds driver."},
        {"field_key": "refi.interest_rate", "display_name": "Refi Rate", "source": "Manual / Debt Quote", "confidence": "Medium", "note": "Post-refi debt-service driver."},
        {"field_key": "opex.property_tax.cost_per_unit_per_year", "display_name": "Property Tax", "source": "Manual / Tax Data", "confidence": "Medium", "note": "Large OpEx line."},
        {"field_key": "opex.management_fee.pct_of_egi", "display_name": "Management Fee", "source": "Manual / Property Mgmt", "confidence": "High", "note": "Usually contract-based."},
    ]


def seed_assumption_metadata() -> None:
    with db_conn() as con:
        for row in default_assumption_metadata_rows():
            con.execute(
                """
                INSERT OR IGNORE INTO assumption_metadata(field_key, display_name, source, confidence, note, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (row["field_key"], row["display_name"], row["source"], row["confidence"], row["note"], now_iso()),
            )
        con.commit()


def load_assumption_metadata() -> pd.DataFrame:
    with db_conn() as con:
        df = pd.read_sql_query(
            "SELECT field_key, display_name, source, confidence, note, updated_at FROM assumption_metadata ORDER BY display_name",
            con,
        )
    return df


def save_assumption_metadata(df: pd.DataFrame) -> None:
    with db_conn() as con:
        for _, row in df.iterrows():
            con.execute(
                """
                INSERT INTO assumption_metadata(field_key, display_name, source, confidence, note, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(field_key) DO UPDATE SET
                    display_name=excluded.display_name,
                    source=excluded.source,
                    confidence=excluded.confidence,
                    note=excluded.note,
                    updated_at=excluded.updated_at
                """,
                (
                    str(row.get("field_key", "")),
                    str(row.get("display_name", "")),
                    str(row.get("source", "Manual")),
                    str(row.get("confidence", "Medium")),
                    str(row.get("note", "")),
                    now_iso(),
                ),
            )
        con.commit()
    append_audit("assumption_metadata_saved", f"Saved {len(df)} assumption metadata rows")


def save_deal_version(deal_name: str, version_label: str, assumptions: Any, kpis: Any) -> None:
    with db_conn() as con:
        con.execute(
            """
            INSERT INTO deal_versions(deal_name, version_label, assumptions_json, kpis_json, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (deal_name, version_label, to_json(assumptions), to_json(kpis), now_iso()),
        )
        con.commit()
    append_audit("deal_version_saved", f"Saved {deal_name} / {version_label}")


def load_deal_versions(limit: int = 20) -> pd.DataFrame:
    with db_conn() as con:
        return pd.read_sql_query(
            "SELECT id, deal_name, version_label, created_at FROM deal_versions ORDER BY id DESC LIMIT ?",
            con,
            params=(limit,),
        )


def save_scenario_results(deal_name: str, base_kpis: Any, scenario_rows: List[Dict[str, Any]], scenario_payloads: List[Tuple[str, Any, Any]]) -> str:
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    base_irr = base_kpis.levered_irr if base_kpis and base_kpis.levered_irr is not None else None
    with db_conn() as con:
        for scenario_name, scenario_assumptions, scenario_kpis in scenario_payloads:
            irr_delta = None
            if base_irr is not None and scenario_kpis and scenario_kpis.levered_irr is not None:
                irr_delta = scenario_kpis.levered_irr - base_irr
            con.execute(
                """
                INSERT INTO scenario_results(
                    run_id, deal_name, scenario_name, levered_irr, unlevered_irr, npv,
                    equity_multiple, irr_delta, assumptions_json, kpis_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    deal_name,
                    scenario_name,
                    None if scenario_kpis is None else scenario_kpis.levered_irr,
                    None if scenario_kpis is None else scenario_kpis.unlevered_irr,
                    None if scenario_kpis is None else scenario_kpis.npv,
                    None if scenario_kpis is None else scenario_kpis.equity_multiple,
                    irr_delta,
                    to_json(scenario_assumptions),
                    to_json(scenario_kpis),
                    now_iso(),
                ),
            )
        con.commit()
    append_audit("scenario_results_saved", f"Saved scenario run {run_id} for {deal_name}")
    return run_id


def load_scenario_results(limit: int = 50) -> pd.DataFrame:
    with db_conn() as con:
        return pd.read_sql_query(
            """
            SELECT id, run_id, deal_name, scenario_name, levered_irr, unlevered_irr, npv,
                   equity_multiple, irr_delta, created_at
            FROM scenario_results
            ORDER BY id DESC
            LIMIT ?
            """,
            con,
            params=(limit,),
        )


def load_audit_log(limit: int = 50) -> pd.DataFrame:
    with db_conn() as con:
        return pd.read_sql_query(
            "SELECT id, event_type, detail, created_at FROM audit_log ORDER BY id DESC LIMIT ?",
            con,
            params=(limit,),
        )


def scenario_recipe_outputs(assumptions, kpis):
    recipes = ["Base", "Exit Cap Expansion", "Cost Overrun", "Lease-Up Delay", "Refi Failure", "Rate Shock", "Rent Recession"]
    rows = []
    payloads = []
    for recipe in recipes:
        aa = apply_scenario(assumptions, recipe)
        kk = run_kpis_only(aa)
        payloads.append((recipe, aa, kk))
        if kk is None:
            rows.append({"Scenario": recipe, "Levered IRR": "Error", "Unlevered IRR": "Error", "NPV": "Error", "Equity Multiple": "Error", "IRR Delta": "Error"})
            continue
        delta = (kk.levered_irr - kpis.levered_irr) if kk.levered_irr is not None and kpis.levered_irr is not None else None
        rows.append({
            "Scenario": recipe,
            "Levered IRR": pct(kk.levered_irr),
            "Unlevered IRR": pct(kk.unlevered_irr),
            "NPV": money(kk.npv),
            "Equity Multiple": xmult(kk.equity_multiple),
            "IRR Delta": "—" if delta is None else f"{delta*100:+.2f} pts",
        })
    return rows, payloads


# =============================================================================
# Page
# =============================================================================

st.set_page_config(page_title="RE DCF Workbench v3.4", layout="wide")
init_db()
APP_VERSION = "v3.4 Dynamic Dependency Tree"
st.title(f"RE DCF Workbench {APP_VERSION}")
st.caption("Diagnostic underwriting interface with live formula traceability, clickable lineage nodes, assumption provenance, scenario database, deal versioning, and audit log.")
st.info("Running build: v3.4 Dynamic Dependency Tree | trace drawer and dependency tree are driven by the same selected node.")


def select_formula_node(name: str) -> None:
    """Streamlit callback: set selected formula before rerun renders the drawer."""
    st.session_state.selected_formula = name


def dependency_tree_text(name: str) -> str:
    """Return a dynamic dependency tree for the currently selected trace node."""
    trees = {
        "Levered IRR": """Levered IRR
├── Equity CF
│   ├── NCFBT = NOI - Debt Service - Ongoing CapEx
│   │   ├── NOI
│   │   └── Debt Service
│   ├── Refi Proceeds
│   ├── Levered Sale Proceeds
│   │   ├── Exit Value
│   │   ├── Loan Payoff
│   │   └── Disposition Fee
│   ├── Equity Reno Draw
│   └── Initial Equity Outflow
└── compute_irr(equity_cfs)""",
        "Unlevered IRR": """Unlevered IRR
├── Unlevered CF
│   ├── NOI
│   ├── Total Reno Draw
│   ├── Ongoing CapEx
│   ├── Acquisition Outflow
│   └── Unlevered Sale Proceeds
│       └── Exit Value
└── compute_irr(unlevered_cfs)""",
        "Equity CF": """Equity CF
├── NCFBT
│   ├── NOI
│   ├── Debt Service
│   └── Ongoing CapEx
├── Refi Proceeds
├── Levered Sale Proceeds
│   └── Exit Value
├── GP Management Fee
├── Equity Reno Draw
└── Initial Equity Outflow""",
        "NOI": """NOI
├── EGI
│   ├── Gross Potential Rent
│   ├── Occupancy / Vacancy
│   ├── Concessions
│   └── Credit Loss
└── Operating Expenses
    ├── Repairs & Maintenance
    ├── Payroll
    ├── Utilities
    ├── Insurance
    ├── Property Tax
    └── Management Fee""",
        "Exit Value": """Exit Value
├── Exit Month NOI
├── Annualization × 12
└── Exit Cap Rate

Levered Sale Proceeds
├── Exit Value
├── Selling Costs
├── Loan Payoff
└── Disposition Fee""",
        "Refi Proceeds": """Refi Proceeds
├── Refi Value
│   ├── NOI at Refi / Stabilized NOI
│   └── Market Cap Rate
├── Refi LTV
├── Acquisition Loan Payoff
├── Construction Loan Payoff
└── Refi Costs""",
        "DSCR Stabilized": """DSCR Stabilized
├── Stabilized Annual NOI
│   └── Stabilized Monthly NOI × 12
└── Stabilized Annual Debt Service
    └── Stabilized Monthly Debt Service × 12""",
        "Yield on Cost": """Yield on Cost
├── Stabilized Annual NOI
└── Total Project Cost
    ├── Purchase Price
    ├── Closing Costs
    ├── Hard Costs
    ├── Soft Costs
    └── Common / Exterior Costs""",
    }
    return trees.get(name, f"{name}\n└── No dependency tree registered yet")


def render_trace_dependency_controls(trace: Dict[str, Dict[str, Any]]) -> None:
    """Show a dynamic dependency tree that follows the selected trace node."""
    selected = st.session_state.get("selected_formula", list(trace.keys())[0])
    fd = trace[selected]
    st.markdown(f"#### Dependency Tree: {selected}")
    st.code(dependency_tree_text(selected), language="text")
    st.caption("Click any available dependency below to jump the drawer and this tree to that node.")

    dependency_buttons = [d for d in fd.get("dependencies", []) if d in trace]
    if selected not in dependency_buttons and selected in trace:
        dependency_buttons = [selected] + dependency_buttons

    if dependency_buttons:
        cols = st.columns(min(4, len(dependency_buttons)))
        for i, dep in enumerate(dependency_buttons):
            cols[i % len(cols)].button(
                f"Trace: {dep}",
                key=f"dynamic_dep_{selected}_{dep}",
                width="stretch",
                on_click=select_formula_node,
                args=(dep,),
            )
    else:
        st.info("No clickable trace dependencies registered for this node yet.")


try:
    assumptions = build_assumptions_from_ui()
    revenue, stab_month, opex, capex, debt, cashflows, waterfall, kpis = run_all_engines(assumptions)
except Exception as exc:
    st.error("Engine run failed.")
    st.exception(exc)
    st.stop()

# KPI header
cols = st.columns(8)
cols[0].metric("Levered IRR", pct(kpis.levered_irr))
cols[1].metric("Unlevered IRR", pct(kpis.unlevered_irr))
cols[2].metric("Equity Multiple", xmult(kpis.equity_multiple))
cols[3].metric("NPV", money(kpis.npv))
cols[4].metric("Yield on Cost", pct(kpis.yield_on_cost))
cols[5].metric("Dev Spread", f"{kpis.development_spread_bps:,.0f} bps")
cols[6].metric("DSCR Stab", xmult(kpis.dscr_stabilized))
cols[7].metric("Stab Month", str(kpis.stabilization_month))

st.divider()

left, right = st.columns([2.2, 1.0], gap="large")

with right:
    st.subheader("Formula Trace Drawer")
    trace = build_formula_trace(assumptions, revenue, opex, capex, debt, cashflows, kpis)
    formula_keys = list(trace.keys())
    if "selected_formula" not in st.session_state:
        st.session_state.selected_formula = formula_keys[0]
    if st.session_state.selected_formula not in formula_keys:
        st.session_state.selected_formula = formula_keys[0]
    selected_formula = st.selectbox(
        "Inspect live KPI / output",
        formula_keys,
        index=formula_keys.index(st.session_state.selected_formula),
        key="selected_formula",
    )
    fd = trace[st.session_state.selected_formula]
    st.markdown(f"### {st.session_state.selected_formula}: {fd['value']}")
    st.markdown("**Formula:**")
    st.code(fd["formula"], language="text")
    st.markdown(f"**Source function:** `{fd['source_function']}`")
    st.markdown(f"**Source file:** `{fd['source_file']}`")
    st.markdown("**Dependencies:** " + ", ".join(f"`{x}`" for x in fd["dependencies"]))
    if fd.get("warnings"):
        for w in fd["warnings"]:
            st.warning(w)
    st.markdown("**Bridge:**")
    st.dataframe(fd["bridge"], hide_index=True, width="stretch")
    st.markdown("**Month-level trace:**")
    md = fd["month_detail"]
    if isinstance(md, pd.DataFrame):
        if len(md) > 16:
            md_show = pd.concat([md.head(8), md.tail(8)])
        else:
            md_show = md
        st.dataframe(md_show, hide_index=True, width="stretch")
    else:
        st.write(md)

with left:
    main_tabs = st.tabs([
        "Command Center",
        "Formula Trace Explorer",
        "Assumption Intelligence",
        "Scenario Recipes",
        "Engine Tables",
        "Audit Notes",
    ])

    with main_tabs[0]:
        st.subheader("Underwriting Command Center")
        exit_m = assumptions.exit.exit_month
        exit_cf = cashflows[exit_m]
        command_rows = [
            {"Bridge": "Revenue → NOI", "Formula": "EGI - OpEx", "Current Output": money(opex[min(stab_month, len(opex)-1)].noi), "Status": "Live"},
            {"Bridge": "NOI → Exit Value", "Formula": "Exit NOI × 12 / Exit Cap", "Current Output": money((exit_cf.noi * 12) / assumptions.exit.exit_cap_rate), "Status": "Live"},
            {"Bridge": "Debt → Refi", "Formula": "Refi Value × LTV - Payoffs - Costs", "Current Output": money(sum(cf.refi_proceeds for cf in cashflows)), "Status": "Live"},
            {"Bridge": "Exit → Levered IRR", "Formula": "IRR(equity cash-flow stream)", "Current Output": pct(kpis.levered_irr), "Status": "Live"},
            {"Bridge": "Property → Unlevered IRR", "Formula": "IRR(unlevered property cash-flow stream)", "Current Output": pct(kpis.unlevered_irr), "Status": "Fixed / Live"},
        ]
        st.dataframe(pd.DataFrame(command_rows), hide_index=True, width="stretch")

        st.markdown("#### KPI Bridge Snapshot")
        bridge_df = pd.DataFrame([
            {"KPI": "Levered IRR", "Value": pct(kpis.levered_irr), "Primary Drivers": "Exit value, refi proceeds, NOI, debt service", "Risk": "High sensitivity to exit cap"},
            {"KPI": "Unlevered IRR", "Value": pct(kpis.unlevered_irr), "Primary Drivers": "Purchase price, NOI, total capex, unlevered exit proceeds", "Risk": "Depends on terminal value"},
            {"KPI": "DSCR", "Value": xmult(kpis.dscr_stabilized), "Primary Drivers": "NOI and debt service at stabilization", "Risk": "Debt quote / refi sizing"},
            {"KPI": "Yield on Cost", "Value": pct(kpis.yield_on_cost), "Primary Drivers": "Stabilized NOI and total project cost", "Risk": "Reno budget and NOI quality"},
        ])
        st.dataframe(bridge_df, hide_index=True, width="stretch")

    with main_tabs[1]:
        st.subheader("Formula Trace Explorer")
        st.caption("Click a node to load its live lineage, bridge, source function, dependencies, and month-level trace into the drawer on the right.")
        st.markdown("#### Live Trace Nodes")

        c1, c2, c3 = st.columns(3)
        with c1:
            st.markdown("#### Return KPIs")
            st.button("Levered IRR", key="node_levered_irr", width="stretch", on_click=select_formula_node, args=("Levered IRR",))
            st.button("Unlevered IRR", key="node_unlevered_irr", width="stretch", on_click=select_formula_node, args=("Unlevered IRR",))
            st.button("DSCR Stabilized", key="node_dscr", width="stretch", on_click=select_formula_node, args=("DSCR Stabilized",))
            st.button("Yield on Cost", key="node_yoc", width="stretch", on_click=select_formula_node, args=("Yield on Cost",))
        with c2:
            st.markdown("#### Value / Liquidity")
            st.button("Exit Value", key="node_exit_value", width="stretch", on_click=select_formula_node, args=("Exit Value",))
            st.button("Refi Proceeds", key="node_refi", width="stretch", on_click=select_formula_node, args=("Refi Proceeds",))
            st.button("Equity CF", key="node_equity_cf", width="stretch", on_click=select_formula_node, args=("Equity CF",))
            st.button("NOI", key="node_noi", width="stretch", on_click=select_formula_node, args=("NOI",))
        with c3:
            st.markdown("#### Source Engines")
            st.write("Revenue → NOI → Debt → Refi → Exit → IRR")
            st.write("Each node routes to a live trace object generated from the current engine run.")
            st.write("The drawer updates through callback state before the page renders, so buttons do not disappear.")

        render_trace_dependency_controls(trace)

    with main_tabs[2]:
        st.subheader("Assumption Intelligence")
        st.caption("Edit assumption source/confidence tags. These save to local SQLite and are separate from the engine math.")
        ai_df = assumption_intelligence(assumptions, kpis)
        meta_df = load_assumption_metadata()
        merged = ai_df.merge(meta_df[["Model Path", "source", "confidence", "note"]].rename(columns={"Model Path": "Model Path"}), on="Model Path", how="left") if "Model Path" in meta_df.columns else ai_df
        st.markdown("#### Impact scan")
        st.dataframe(ai_df, hide_index=True, width="stretch")

        st.markdown("#### Editable assumption provenance")
        edit_df = load_assumption_metadata()
        edited = st.data_editor(
            edit_df,
            hide_index=True,
            width="stretch",
            num_rows="dynamic",
            column_config={
                "source": st.column_config.SelectboxColumn("source", options=["Manual", "Imported", "Calculated", "Market Benchmark", "Historical Actual", "Formula Derived", "Scenario Override", "Manual / Market Comp", "Manual / Debt Quote", "Manual / Budget"]),
                "confidence": st.column_config.SelectboxColumn("confidence", options=["High", "Medium", "Low", "Unknown", "Low-Medium"]),
            },
            key="assumption_metadata_editor",
        )
        if st.button("Save assumption source/confidence tags", type="primary"):
            save_assumption_metadata(edited)
            st.success("Assumption metadata saved to local database.")

    with main_tabs[3]:
        st.subheader("Scenario Recipes")
        scenario_deal_name = st.text_input("Deal name for scenario database", value=assumptions.property.name or "Test Deal")
        rows, scenario_payloads = scenario_recipe_outputs(assumptions, kpis)
        scenario_df = pd.DataFrame(rows)
        st.dataframe(scenario_df, hide_index=True, width="stretch")

        if st.button("Save scenario results to local database", type="primary"):
            run_id = save_scenario_results(scenario_deal_name, kpis, rows, scenario_payloads)
            st.success(f"Scenario run saved: {run_id}")

        st.markdown("#### Saved scenario runs")
        saved = load_scenario_results(limit=25)
        if saved.empty:
            st.info("No saved scenario results yet.")
        else:
            display_saved = saved.copy()
            for col in ["levered_irr", "unlevered_irr", "irr_delta"]:
                display_saved[col] = display_saved[col].map(lambda v: "—" if pd.isna(v) else f"{v*100:.2f}%")
            display_saved["npv"] = display_saved["npv"].map(lambda v: "—" if pd.isna(v) else money(v))
            display_saved["equity_multiple"] = display_saved["equity_multiple"].map(lambda v: "—" if pd.isna(v) else xmult(v))
            st.dataframe(display_saved, hide_index=True, width="stretch")

        st.markdown("""
**Recipe definitions**
- **Exit Cap Expansion:** exit cap +50 bps.
- **Cost Overrun:** hard cost +15%, contingency +5 pts, renovation period +3 months.
- **Lease-Up Delay:** absorption +6 months and concessions +2 weeks.
- **Refi Failure:** refinance disabled.
- **Rate Shock:** acquisition, construction, and refi rates +100 bps.
- **Rent Recession:** rent growth -150 bps and stabilized occupancy -3 pts.
""")

    with main_tabs[4]:
        st.subheader("Engine Tables")
        max_month = st.slider("Display months", 12, assumptions.timeline.hold_months, min(36, assumptions.timeline.hold_months), 1)
        engine_tab_names = ["Revenue", "Unit Cohorts", "OpEx", "CapEx", "Debt", "DCF"]
        t_rev, t_unit, t_opex, t_capex, t_debt, t_dcf = st.tabs(engine_tab_names)
        with t_rev:
            st.code("EGI = GPR + Other Income - Vacancy Loss - Credit Loss", language="text")
            df = dataclass_rows(revenue[: max_month + 1]).drop(columns=["unit_type_detail"], errors="ignore")
            st.dataframe(df, hide_index=True, width="stretch")
        with t_unit:
            st.dataframe(flatten_unit_detail(revenue, max_month), hide_index=True, width="stretch")
        with t_opex:
            st.code("NOI = EGI - total OpEx", language="text")
            st.dataframe(dataclass_rows(opex[: max_month + 1]), hide_index=True, width="stretch")
        with t_capex:
            st.code("S-curve draw = total renovation budget × incremental draw percentage", language="text")
            st.dataframe(dataclass_rows(capex[: max_month + 1]), hide_index=True, width="stretch")
        with t_debt:
            st.code("Debt service = scheduled acquisition + refi payments. Construction interest is capitalized.", language="text")
            debt_df = dataclass_rows(debt[: max_month + 1])
            st.dataframe(debt_df.drop(columns=["acq_loan", "const_loan", "refi_loan"], errors="ignore"), hide_index=True, width="stretch")
        with t_dcf:
            st.code("Equity CF = NCFBT + refi proceeds + sale proceeds - GP fee - equity reno - initial equity", language="text")
            st.dataframe(dataclass_rows(cashflows[: max_month + 1]), hide_index=True, width="stretch")

    with main_tabs[5]:
        st.subheader("Deal Versioning & Audit Log")

        vcol1, vcol2 = st.columns(2)
        with vcol1:
            deal_name = st.text_input("Deal name", value=assumptions.property.name or "Test Deal", key="version_deal_name")
        with vcol2:
            version_label = st.text_input("Version label", value=f"v_{datetime.now().strftime('%Y%m%d_%H%M')}", key="version_label")

        if st.button("Save current deal version", type="primary"):
            save_deal_version(deal_name, version_label, assumptions, kpis)
            st.success("Deal version saved to local database.")

        st.markdown("#### Saved deal versions")
        versions = load_deal_versions(limit=25)
        if versions.empty:
            st.info("No saved deal versions yet.")
        else:
            st.dataframe(versions, hide_index=True, width="stretch")

        st.markdown("#### Audit log")
        audit = load_audit_log(limit=50)
        if audit.empty:
            st.info("No audit events yet.")
        else:
            st.dataframe(audit, hide_index=True, width="stretch")

        st.markdown("#### Current baseline")
        st.success("Engine runs, 43 tests pass, unlevered IRR includes terminal sale proceeds, and IRR helper has underflow guardrails.")
        st.markdown("""
**Workbench v3.1 additions**
- Formula Explorer nodes route to a live trace object.
- Formula Drawer shows exact source function, source file, dependencies, bridge rows, and month-level trace.
- Levered IRR, Unlevered IRR, Equity CF, NOI, Exit Value, Refi Proceeds, DSCR, and Yield on Cost are traceable.
- Assumption source/confidence tags are editable and stored locally.
- Scenario results, deal versions, and audit events are saved locally.

**Still not final production UX**
- Database is local SQLite only.
- No multi-user auth.
- No cloud deployment.
- No external market data feed yet.
""")
